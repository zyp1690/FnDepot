#!/bin/bash
# 构建内网管家 .fpk 安装包
# 依赖：go（1.21+）、python3 + Pillow（生成图标）、fnpack（飞牛官方打包工具，缺失时自动下载）
#
# 用法：
#   ./scripts/build.sh              # 构建 x86_64 包
#   GOARCH=arm64 ./scripts/build.sh # 交叉编译 arm64 包（需本机 go 支持该目标）

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

GOARCH="${GOARCH:-amd64}"
case "$GOARCH" in
    amd64) ARCH_LABEL="x86_64" ;;
    arm64) ARCH_LABEL="arm64" ;;
    *)     ARCH_LABEL="$GOARCH" ;;
esac

VERSION="$(sed -n 's/^version[[:space:]]*=[[:space:]]*//p' fpk/manifest | head -1 | tr -d '[:space:]')"
APPNAME="$(sed -n 's/^appname[[:space:]]*=[[:space:]]*//p' fpk/manifest | head -1 | tr -d '[:space:]')"
[ -n "$VERSION" ] || { echo "manifest 缺少 version"; exit 1; }
[ -n "$APPNAME" ] || { echo "manifest 缺少 appname"; exit 1; }

# ---- 1. fnpack ----
FNPACK="${FNPACK:-}"
if [ -z "$FNPACK" ]; then
    if command -v fnpack >/dev/null 2>&1; then
        FNPACK="$(command -v fnpack)"
    elif [ -x "scripts/tools/fnpack" ]; then
        FNPACK="scripts/tools/fnpack"
    else
        echo "== 未找到 fnpack，尝试下载官方版本"
        mkdir -p scripts/tools
        curl -fsSL -o scripts/tools/fnpack "https://static2.fnnas.com/fnpack/fnpack-1.2.3-linux-amd64"
        chmod +x scripts/tools/fnpack
        FNPACK="scripts/tools/fnpack"
    fi
fi

case "$FNPACK" in
    /*) : ;;
    *)  FNPACK="$ROOT/$FNPACK" ;;
esac

# ---- 2. 编译二进制 ----
echo "== 编译 $APPNAME ($GOARCH)"
( cd src && CGO_ENABLED=0 GOOS=linux GOARCH="$GOARCH" go build -trimpath -ldflags "-s -w" -o "../fpk/app/$APPNAME" . )
chmod 755 "fpk/app/$APPNAME"

# ---- 3. 图标 ----
echo "== 生成图标"
python3 scripts/make_icon.py

# ---- 4. 打包 ----
echo "== 打包 fpk"
mkdir -p dist
( cd dist && "$FNPACK" build -d "$ROOT/fpk" )
OUT="dist/${APPNAME}-${VERSION}-${ARCH_LABEL}.fpk"
mv -f "dist/${APPNAME}.fpk" "$OUT"
echo "== 完成：$OUT ($(du -h "$OUT" | cut -f1))"
