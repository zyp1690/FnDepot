from PIL import Image, ImageDraw

S = 1024
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))

# vertical gradient background in a rounded square
grad = Image.new("RGB", (S, S))
top = (29, 78, 216)      # #1d4ed8
bottom = (56, 189, 248)  # #38bdf8
for y in range(S):
    k = y / (S - 1)
    r = int(top[0] + (bottom[0] - top[0]) * k)
    g = int(top[1] + (bottom[1] - top[1]) * k)
    b = int(top[2] + (bottom[2] - top[2]) * k)
    grad.paste((r, g, b), (0, y, S, y + 1))

mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=255)
img.paste(grad, (0, 0), mask)

d = ImageDraw.Draw(img)
W = (255, 255, 255, 255)

# two node rings: left (public side) and right (LAN side)
cx1, cx2, cy = S * 0.24, S * 0.76, S * 0.5
r_out, r_in = S * 0.075, S * 0.038
for cx in (cx1, cx2):
    d.ellipse([cx - r_out, cy - r_out, cx + r_out, cy + r_out], outline=(255, 255, 255, 120), width=int(S * 0.018))
    d.ellipse([cx - r_in, cy - r_in, cx + r_in, cy + r_in], fill=W)

# two exchange arrows between the nodes
gi = S * 0.035
x0, x1 = cx1 + S * 0.085, cx2 - S * 0.085
head = S * 0.055
w = int(S * 0.028)

# upper arrow: left -> right
yc = cy - gi
d.line([x0, yc, x1 - head * 0.6, yc], fill=W, width=w)
d.polygon([(x1, yc), (x1 - head, yc - head * 0.62), (x1 - head, yc + head * 0.62)], fill=W)

# lower arrow: right -> left
yc = cy + gi
d.line([x1, yc, x0 + head * 0.6, yc], fill=W, width=w)
d.polygon([(x0, yc), (x0 + head, yc - head * 0.62), (x0 + head, yc + head * 0.62)], fill=W)

img.save("/tmp/icon-1024.png")
for size, path in [(256, "fpk/ICON_256.PNG"), (64, "fpk/ICON.PNG"),
                   (256, "fpk/app/ui/images/icon_256.png"), (64, "fpk/app/ui/images/icon_64.png"),
                   (256, "fpk/app/ui/images/icon-256.png"), (64, "fpk/app/ui/images/icon-64.png")]:
    img.resize((size, size), Image.LANCZOS).save(path)
print("icons written")
