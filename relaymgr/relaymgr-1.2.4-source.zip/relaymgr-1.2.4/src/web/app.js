/* 内网管家 · 前端交互 */
(() => {
  "use strict";

  const $ = (sel) => document.querySelector(sel);
  const state = {
    initialized: false,
    authed: false,
    lan: false,
    forwards: [],
    hosts: [],
    interfaces: [],
    scan: null,
    view: "overview",
    editing: null,
    pollTimer: null,
    scanTimer: null,
    proto: "tcp",
    net: null,
    hostQuery: "",
    onlyRisk: false,
    onlyNew: false,
  };

  const THEME_KEY = "relaymgr.theme";
  const THEMES = ["teal", "graphite", "dark"];
  function applyTheme(name) {
    const t = THEMES.indexOf(name) >= 0 ? name : "teal";
    document.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
    const sel = document.querySelector("#setTheme");
    if (sel) sel.value = t;
  }
  function initTheme() {
    let saved = "teal";
    try { saved = localStorage.getItem(THEME_KEY) || "teal"; } catch (e) {}
    document.documentElement.setAttribute("data-theme", THEMES.indexOf(saved) >= 0 ? saved : "teal");
  }
  initTheme();

  const TEMPLATES = {
    rdp: { name: "Windows 远程桌面", proto: "tcp", listen: "13389", targetPort: "3389" },
    ssh: { name: "SSH 登录", proto: "tcp", listen: "10022", targetPort: "22" },
    vnc: { name: "VNC 远程桌面", proto: "tcp", listen: "15900", targetPort: "5900" },
    smb: { name: "SMB 文件共享", proto: "tcp", listen: "10445", targetPort: "445" },
    web: { name: "Web 服务", proto: "tcp", listen: "18080", targetPort: "8080" },
  };

  // ---------- 基础工具 ----------

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function showError(node, msg) {
    if (!node) return;
    node.textContent = msg;
    node.classList.toggle("hidden", !msg);
  }

  function toast(msg, bad) {
    const node = $("#toast");
    node.textContent = msg;
    node.className = "toast" + (bad ? " bad" : "");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => node.classList.add("hidden"), 2600);
  }

  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + " B";
    const units = ["KB", "MB", "GB", "TB"];
    let i = -1;
    do { n /= 1024; i++; } while (n >= 1024 && i < units.length - 1);
    return n.toFixed(n >= 100 ? 0 : 1) + " " + units[i];
  }

  function fmtDuration(sec) {
    sec = Math.max(0, Math.floor(Number(sec) || 0));
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    if (d) return d + " 天 " + h + " 小时";
    if (h) return h + " 小时 " + m + " 分";
    return m + " 分钟";
  }

  function fmtTime(iso) {
    const d = new Date(iso);
    if (isNaN(d.getTime()) || d.getFullYear() < 1970) return "—";
    const p = (x) => String(x).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " +
      p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
  }

  async function api(path, opts) {
    const options = Object.assign({ credentials: "same-origin", headers: {} }, opts || {});
    if (options.body && typeof options.body !== "string") {
      options.body = JSON.stringify(options.body);
      options.headers["Content-Type"] = "application/json";
    }
    const res = await fetch(path, options);
    let data = null;
    try { data = await res.json(); } catch (_) { data = null; }
    if (!res.ok) {
      const msg = (data && data.error) || ("请求失败（HTTP " + res.status + "）");
      const err = new Error(msg);
      err.status = res.status;
      throw err;
    }
    return data || {};
  }

  // ---------- 登录 / 初始化 ----------

  function showGate(mode) {
    $("#gate").classList.remove("hidden");
    $("#app").classList.add("hidden");
    $("#gateLogin").classList.toggle("hidden", mode !== "login");
    $("#gateSetup").classList.toggle("hidden", mode !== "setup");
    showError($("#gateError"), "");
    stopPolling();
    if (mode === "login") setTimeout(() => $("#loginPwd").focus(), 30);
  }

  function configureSetup() {
    // 初始化入口不再区分内网/公网，首次打开直接设置口令。
    $("#setupNote").textContent = "首次使用，设置管理口令即完成初始化；设置后本页只接受登录。";
  }

  async function boot() {
    try {
      const s = await api("/api/state");
      state.initialized = s.initialized;
      state.authed = s.authed;
      state.lan = s.lan;
      if (s.scanTimeoutMs) state.scanTimeoutMs = s.scanTimeoutMs;
      if (!s.initialized) {
        configureSetup();
        showGate("setup");
        return;
      }
      if (!s.authed) {
        showGate("login");
        if (s.lockRemainSec > 0) {
          showError($("#gateError"), "登录失败次数过多，请 " + fmtRemain(s.lockRemainSec) + "后再试");
        }
        return;
      }
      applyState(s);
      enterApp();
    } catch (e) {
      showGate("login");
      showError($("#gateError"), e.message);
    }
  }

  function enterApp() {
    $("#gate").classList.add("hidden");
    $("#app").classList.remove("hidden");
    renderAll();
    loadHosts();
    startPolling();
  }

  async function loadHosts() {
    try {
      const r = await api("/api/hosts");
      state.hosts = r.hosts || [];
      state.interfaces = r.interfaces || state.interfaces;
      renderHosts();
      renderInterfaces();
    } catch (_) {}
  }

  async function doLogin() {
    const pwd = $("#loginPwd").value.trim();
    if (!pwd) { showError($("#gateError"), "请输入管理口令"); return; }
    const btn = $("#loginBtn");
    btn.disabled = true;
    try {
      await api("/api/login", { method: "POST", body: { password: pwd } });
      $("#loginPwd").value = "";
      await boot();
    } catch (e) {
      showError($("#gateError"), e.message);
    } finally {
      btn.disabled = false;
    }
  }

  function fmtRemain(sec) {
    sec = Math.max(1, Math.floor(sec));
    if (sec < 60) return sec + " 秒";
    if (sec < 3600) return Math.floor(sec / 60) + " 分 " + (sec % 60) + " 秒";
    return Math.floor(sec / 3600) + " 小时 " + Math.floor((sec % 3600) / 60) + " 分";
  }

  async function doSetup() {
    const pwd = $("#setupPwd").value.trim();
    const pwd2 = $("#setupPwd2").value.trim();
    if (pwd.length < 10) { showError($("#gateError"), "口令至少 10 位"); return; }
    if (pwd !== pwd2) { showError($("#gateError"), "两次输入的口令不一致"); return; }
    const btn = $("#setupBtn");
    btn.disabled = true;
    try {
      await api("/api/setup", { method: "POST", body: { password: pwd } });
      $("#setupPwd").value = ""; $("#setupPwd2").value = "";
      await boot();
      toast("初始化完成");
    } catch (e) {
      showError($("#gateError"), e.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function doLogout() {
    try { await api("/api/logout", { method: "POST" }); } catch (_) {}
    showGate("login");
  }

  // ---------- 状态 ----------

  function addrRow(tag, url) {
    const row = el("div", "addr-row");
    row.appendChild(el("span", "addr-tag", tag));
    row.appendChild(el("span", "mono", url));
    return row;
  }

  function renderNetInfo() {
    const n = state.net || {};
    const port = n.listenPort || n.port || 8899;
    const mode = n.listenMode || (n.ipv6 ? "IPv4+IPv6" : "仅 IPv4");
    const a4 = n.addrs4 || [];
    const a6 = n.addrs6 || [];

    const line = "管理界面 :" + port + " · " + mode + (a4.length ? " · 局域网 http://" + a4[0] + ":" + port : "");
    const lineNode = $("#overviewStack");
    if (lineNode && lineNode.textContent !== line) lineNode.textContent = line;

    const box = $("#addrList");
    if (!box) return;
    const sig = [port, mode, a4.join(","), a6.join(",")].join("#");
    if (box.dataset.sig === sig) return;
    box.dataset.sig = sig;
    box.textContent = "";
    a4.forEach((ip) => box.appendChild(addrRow("IPv4", "http://" + ip + ":" + port)));
    a6.forEach((ip) => box.appendChild(addrRow("IPv6", "http://[" + ip + "]:" + port)));
    if (!a4.length && !a6.length) {
      box.appendChild(el("span", "addr-none", "未检测到可用的局域网地址，请检查 NAS 网络配置"));
    }
  }

  function applyState(s) {
    state.net = {
      port: s.port, listenPort: s.listenPort, ipv6: s.ipv6,
      listenMode: s.listenMode, addrs4: s.addrs4 || [], addrs6: s.addrs6 || [],
    };
    state.forwards = s.forwards || [];
    state.hosts = s.hostCount ? state.hosts : state.hosts;
    state.interfaces = s.interfaces || [];
    state.scan = s.scan || null;
    renderNetInfo();
    $("#topHost").textContent = s.hostname || "飞牛 NAS";
    $("#topAddress").textContent = "管理端口 :" + (s.listenPort || s.port || 8899);
    $("#navUptime").textContent = "已运行 " + fmtDuration(s.uptimeSec);
    renderMetrics();
    if (state.view === "overview" || state.view === "forwards") renderForwards();
  }

  function renderAll() {
    renderForwards();
    renderHosts();
    renderScanStatus();
    fillSettings();
    renderInterfaces();
  }

  function renderMetrics() {
    const list = state.forwards;
    const running = list.filter((f) => f.running).length;
    const active = list.reduce((n, f) => n + (Number(f.active) || 0), 0);
    const bytes = list.reduce((n, f) => n + (Number(f.bytesIn) || 0) + (Number(f.bytesOut) || 0), 0);
    $("#mRunning").textContent = running;
    $("#mRunningNote").textContent = "共 " + list.length + " 条规则";
    $("#mActive").textContent = active;
    $("#mBytes").textContent = fmtBytes(bytes);
    $("#mHosts").textContent = state.hosts.length;
    if (state.scan && state.scan.finishedAt && fmtTime(state.scan.finishedAt) !== "—" && !state.scan.running) {
      $("#mHostsNote").textContent = "上次扫描 " + fmtTime(state.scan.finishedAt);
    } else if (state.scan && state.scan.running) {
      $("#mHostsNote").textContent = "扫描中 " + state.scan.done + "/" + state.scan.total;
    } else if (state.hosts.length) {
      $("#mHostsNote").textContent = "来自上次扫描结果";
    }
  }

  // ---------- 转发规则 ----------

  function statusCell(f) {
    const wrap = el("span", "status");
    let cls = "off";
    let text = "已停用";
    let title = "";
    if (f.running) { cls = "on"; text = "运行中"; }
    else if (f.enabled && f.lastError) { cls = "err"; text = "启动失败"; title = String(f.lastError); }
    else if (f.enabled) { cls = "off"; text = "待启动"; }
    wrap.appendChild(el("span", "dot " + cls));
    wrap.appendChild(el("span", "", text));
    if (title) wrap.title = title;
    return wrap;
  }

  function miniBtn(label, cls, onClick) {
    const b = el("button", "mini" + (cls ? " " + cls : ""), label);
    b.type = "button";
    b.addEventListener("click", onClick);
    return b;
  }

  function addCells(tr, cells) {
    cells.forEach((c) => tr.appendChild(c));
    return tr;
  }

  function renderForwards() {
    const full = $("#forwardRows");
    const brief = $("#overviewRows");
    full.innerHTML = "";
    brief.innerHTML = "";

    state.forwards.forEach((f) => {
      const tr = document.createElement("tr");
      tr.appendChild(el("td", "", f.name));
      const protoTd = el("td");
      protoTd.appendChild(el("span", "tag " + f.proto, f.proto.toUpperCase()));
      tr.appendChild(protoTd);
      tr.appendChild(el("td", "mono", f.listen));
      const target = el("td", "mono", f.targetHost + ":" + f.targetPort);
      if (f.remark) target.title = f.remark;
      tr.appendChild(target);
      const traffic = el("td", "mono", (Number(f.active) || 0) + " · " + fmtBytes((Number(f.bytesIn) || 0) + (Number(f.bytesOut) || 0)));
      traffic.title = "累计 " + (Number(f.total) || 0) + " 次连接";
      tr.appendChild(traffic);
      const st = el("td");
      st.appendChild(statusCell(f));
      tr.appendChild(st);

      const actions = el("td", "right");
      const box = el("span", "row-actions");
      box.appendChild(miniBtn("编辑", "", () => openModal(f)));
      box.appendChild(miniBtn(f.enabled ? "停用" : "启用", "", async () => {
        try {
          const r = await api("/api/forwards/toggle", { method: "POST", body: { id: f.id, enabled: !f.enabled } });
          state.forwards = r.forwards || [];
          renderForwards();
          renderMetrics();
          toast(f.enabled ? "已停用 " + f.name : "已启用 " + f.name);
        } catch (e) { toast(e.message, true); }
      }));
      box.appendChild(miniBtn("删除", "danger", async () => {
        if (!confirm("删除规则「" + f.name + "」？对应监听端口会立即关闭。")) return;
        try {
          await api("/api/forwards?id=" + encodeURIComponent(f.id), { method: "DELETE" });
          state.forwards = state.forwards.filter((x) => x.id !== f.id);
          renderForwards();
          renderMetrics();
          toast("已删除");
        } catch (e) { toast(e.message, true); }
      }));
      actions.appendChild(box);
      tr.appendChild(actions);
      full.appendChild(tr);

      const btr = document.createElement("tr");
      btr.appendChild(el("td", "", f.name));
      const p2 = el("td");
      p2.appendChild(el("span", "tag " + f.proto, f.proto.toUpperCase()));
      btr.appendChild(p2);
      btr.appendChild(el("td", "mono", f.listen));
      btr.appendChild(el("td", "mono", f.targetHost + ":" + f.targetPort));
      const st2 = el("td");
      st2.appendChild(statusCell(f));
      btr.appendChild(st2);
      brief.appendChild(btr);
    });

    $("#forwardEmpty").classList.toggle("hidden", state.forwards.length > 0);
    $("#overviewEmpty").classList.toggle("hidden", state.forwards.length > 0);
  }

  // ---------- 规则表单 ----------

  function setProto(proto) {
    state.proto = proto;
    document.querySelectorAll("#protoSeg button").forEach((b) => {
      b.classList.toggle("active", b.dataset.proto === proto);
    });
  }

  function openModal(rule) {
    state.editing = rule || null;
    $("#modalTitle").textContent = rule ? "编辑转发" : "新建转发";
    $("#fName").value = rule ? rule.name : "";
    $("#fListen").value = rule ? rule.listen : "";
    $("#fTargetHost").value = rule ? rule.targetHost : "";
    $("#fTargetPort").value = rule ? rule.targetPort : "";
    $("#fRemark").value = rule ? (rule.remark || "") : "";
    $("#fEnabled").checked = rule ? !!rule.enabled : true;
    setProto(rule ? rule.proto : "tcp");
    showError($("#formError"), "");
    $("#modal").classList.remove("hidden");
    setTimeout(() => $("#fName").focus(), 30);
  }

  function closeModal() {
    $("#modal").classList.add("hidden");
    state.editing = null;
  }

  async function saveForward() {
    const body = {
      id: state.editing ? state.editing.id : "",
      name: $("#fName").value.trim(),
      proto: state.proto,
      listen: Number($("#fListen").value),
      targetHost: $("#fTargetHost").value.trim(),
      targetPort: Number($("#fTargetPort").value),
      enabled: $("#fEnabled").checked,
      remark: $("#fRemark").value.trim(),
    };
    if (!body.listen || !body.targetHost || !body.targetPort) {
      showError($("#formError"), "监听端口、目标地址、目标端口都不能为空");
      return;
    }
    const btn = $("#modalSave");
    btn.disabled = true;
    try {
      const r = await api("/api/forwards", { method: "POST", body });
      state.forwards = r.forwards || [];
      closeModal();
      renderForwards();
      renderMetrics();
      toast("规则已保存");
    } catch (e) {
      showError($("#formError"), e.message);
    } finally {
      btn.disabled = false;
    }
  }

  function applyTemplate(key) {
    const t = TEMPLATES[key];
    if (!t) return;
    $("#fName").value = t.name;
    $("#fListen").value = t.listen;
    $("#fTargetPort").value = t.targetPort;
    setProto(t.proto);
    if (!$("#fTargetHost").value) $("#fTargetHost").focus();
  }

  // ---------- 端口扫描 ----------

  // 把网卡网段扩到同一 /16，方便一次扫完整栋/整层网络。
  function wideRange(cidr) {
    const parts = String(cidr || "").split("/");
    const octets = (parts[0] || "").split(".");
    if (octets.length !== 4) return "";
    const mask = Number(parts[1] || "32");
    if (!isNaN(mask) && mask <= 16) return "";
    return octets[0] + "." + octets[1] + ".0.0/16";
  }

  function renderInterfaces() {
    const list = $("#scanStartList");
    const start = $("#scanStart");
    if (!list || !start) return;
    const prev = start.value;
    list.innerHTML = "";
    state.interfaces.forEach((i) => {
      const add = (val, label) => {
        const o = el("option", "", label);
        o.value = val;
        list.appendChild(o);
      };
      add(i.cidr, i.name + " · " + i.cidr);
      const wide = wideRange(i.cidr);
      if (wide) add(wide, i.name + " · " + wide + "（大范围 /16）");
      add(i.addr4 || i.cidr, i.name + " · 本机 " + (i.addr4 || ""));
    });
    if ((!state.scan || !state.scan.running) && !start.value && state.interfaces.length) {
      let def = prev || state.interfaces[0].cidr;
      if (/\/32$/.test(def)) def = def.replace(/\/32$/, "/24");
      start.value = def;
    }
  }

  function flagTag(f) {
    const map = { self: ["本机", "tag self"], gateway: ["网关", "tag gateway"], new: ["新设备", "tag new"] };
    return map[f] ? el("span", map[f][1], map[f][0]) : null;
  }

  function hostMatches(h) {
    const q = state.hostQuery.trim().toLowerCase();
    if (q) {
      const parts = [h.ip, h.hostname, h.vendor, h.kind]
        .concat((h.services || []).map((x) => x.port + " " + x.name))
        .concat((h.openPorts || []).map((p) => String(p)))
        .concat(h.risks || []);
      if (!parts.join(" ").toLowerCase().includes(q)) return false;
    }
    if (state.onlyRisk && !(h.risks || []).length) return false;
    if (state.onlyNew && !(h.flags || []).includes("new")) return false;
    return true;
  }

  function renderHosts() {
    const tbody = $("#hostRows");
    tbody.innerHTML = "";
    // 同一 IP 只渲染一行（后端已按 IP 合并，这里再兜一层，防止旧数据重复）。
    const seen = new Map();
    state.hosts.filter(hostMatches).forEach((h) => {
      const prev = seen.get(h.ip);
      if (!prev || (h.openPorts || []).length >= (prev.openPorts || []).length) {
        seen.set(h.ip, h);
      }
    });
    const list = Array.from(seen.values());
    const treeMode = state.scanView === "tree";
    $("#hostTableWrap").classList.toggle("hidden", treeMode);
    $("#hostTree").classList.toggle("hidden", !treeMode);
    if (treeMode) renderTree(list);
    if (!treeMode) list.forEach((h) => {
      const tr = document.createElement("tr");
      const ipTd = el("td", "mono ip-cell", h.ip);
      if (h.range) {
        const sub = el("div", "cell-sub", h.range);
        sub.title = "扫描范围: " + h.range;
        ipTd.appendChild(sub);
      }
      tr.appendChild(ipTd);

      const nameTd = el("td", "");
      const name = el("div", "", h.hostname || "—");
      name.style.fontWeight = "600";
      nameTd.appendChild(name);
      nameTd.appendChild(el("div", "cell-sub",
        [h.kind, h.vendor].filter(Boolean).join(" · ") || "未知类型"));
      tr.appendChild(nameTd);

      const svcTd = el("td", "svc-cell");
      const services = (h.services && h.services.length)
        ? h.services
        : (h.openPorts || []).map((port) => ({ port, name: "" }));
      if (!services.length) {
        svcTd.textContent = "—";
      } else {
        const shown = services.slice(0, 4);
        shown.forEach((svc) => {
          const chip = el("span", "svc-chip", svc.name ? svc.port + " " + svc.name : String(svc.port));
          if (svc.banner) chip.title = svc.port + " " + (svc.name || "") + " · " + svc.banner;
          svcTd.appendChild(chip);
        });
        const totalPorts = (h.openPorts || []).length;
        const extra = totalPorts - shown.length;
        if (extra > 0) {
          const more = el("span", "svc-more", "+" + extra);
          more.title = "另有端口: " + (h.openPorts || []).slice(shown.length).join(", ");
          svcTd.appendChild(more);
        }
      }
      if (h.smb) {
        const smbChip = el("span", "svc-chip smb", "SMB");
        smbChip.title = h.smb;
        svcTd.appendChild(smbChip);
      }
      tr.appendChild(svcTd);

      const flagTd = el("td", "tag-cell");
      (h.flags || []).forEach((f) => {
        const tag = flagTag(f);
        if (tag) flagTd.appendChild(tag);
      });
      if (!flagTd.childNodes.length) flagTd.textContent = "—";
      tr.appendChild(flagTd);

      const riskTd = el("td", "tag-cell");
      const risks = h.risks || [];
      if (!risks.length) {
        riskTd.textContent = "—";
      } else {
        risks.slice(0, 2).forEach((r) => riskTd.appendChild(el("span", "tag warn", r)));
        if (risks.length > 2) {
          const more = el("span", "tag", "+" + (risks.length - 2));
          more.title = risks.join("；");
          riskTd.appendChild(more);
        }
      }
      tr.appendChild(riskTd);

      const actions = el("td", "right");
      const box = el("span", "row-actions");
      const ports = h.openPorts || [];
      if (ports.includes(3389)) {
        box.appendChild(miniBtn("转发 RDP", "", () => quickForward(h, 3389)));
      }
      const other = ports.filter((p) => p !== 3389)[0];
      if (other) box.appendChild(miniBtn("转发 " + other, "", () => quickForward(h, other)));
      box.appendChild(miniBtn("自定义", "", () => {
        openModal(null);
        $("#fTargetHost").value = h.ip;
      }));
      actions.appendChild(box);
      tr.appendChild(actions);
      tbody.appendChild(tr);
    });

    $("#hostSum").textContent = "共 " + state.hosts.length + " 台 / 显示 " + list.length + " 台";
    const empty = $("#hostEmpty");
    empty.classList.toggle("hidden", list.length > 0);
    if (!list.length) {
      if (state.scan && state.scan.running) {
        empty.textContent = "正在扫描 " + (state.scan.cidr || "") + " …";
      } else {
        empty.textContent = state.hosts.length
          ? "没有符合筛选条件的主机，清空搜索或取消勾选试试。"
          : "尚未扫描。选择网段与档位后点「开始扫描」；标准档扫一个 /24 通常十几秒。";
      }
    }
    renderMetrics();
  }

  function renderTree(list) {
    const tree = $("#hostTree");
    tree.innerHTML = "";
    list.forEach((h) => {
      const li = el("li", "tree-node");
      const head = el("div", "tree-head");
      head.appendChild(el("span", "mono tree-ip", h.ip));
      head.appendChild(el("span", "tree-name", h.hostname || h.kind || "未知设备"));
      (h.flags || []).forEach((f) => {
        const t = flagTag(f);
        if (t) head.appendChild(t);
      });
      (h.risks || []).slice(0, 1).forEach((r) => head.appendChild(el("span", "tag warn", r)));
      const ports0 = h.openPorts || [];
      const fav = ports0.includes(3389) ? 3389 : ports0[0];
      if (fav) {
        const fwd = miniBtn("转发 " + fav, "", () => quickForward(h, fav));
        fwd.classList.add("tree-act");
        head.appendChild(fwd);
      }
      li.appendChild(head);
      const meta = [h.kind, h.vendor, h.mac, h.smb].filter(Boolean).join(" · ");
      if (meta) li.appendChild(el("div", "tree-sub", meta));
      const services = (h.services && h.services.length)
        ? h.services
        : (h.openPorts || []).map((port) => ({ port, name: "" }));
      const ul = el("ul", "tree-ports");
      if (!services.length) ul.appendChild(el("li", "tree-empty", "未发现开放端口"));
      const addPortRow = (svc) => {
        const row = el("li", "tree-port");
        row.appendChild(el("span", "mono tree-port-no", String(svc.port)));
        row.appendChild(el("span", "tree-port-name", svc.name || "TCP"));
        if (svc.banner) row.title = svc.port + " " + (svc.name || "") + " · " + svc.banner;
        ul.appendChild(row);
      };
      const firstN = services.slice(0, 12);
      firstN.forEach(addPortRow);
      if (services.length > firstN.length) {
        const rest = services.slice(firstN.length);
        const more = el("li", "tree-more", "还有 " + rest.length + " 个端口，展开");
        more.addEventListener("click", () => {
          rest.forEach(addPortRow);
          more.remove();
        });
        ul.appendChild(more);
      }
      li.appendChild(ul);
      tree.appendChild(li);
    });
  }

  function exportHosts() {
    const rows = [["IP", "主机名", "类型", "厂商", "MAC", "开放端口", "服务", "SMB", "风险", "扫描范围", "最后发现"]];
    state.hosts.forEach((h) => {
      rows.push([
        h.ip,
        h.hostname || "",
        h.kind || "",
        h.vendor || "",
        h.mac || "",
        (h.openPorts || []).join(" "),
        (h.services || []).map((x) => x.port + " " + (x.name || "")).join(" | "),
        h.smb || "",
        (h.risks || []).join(" | "),
        h.range || "",
        h.lastSeen || "",
      ]);
    });
    const csv = "\ufeff" + rows
      .map((r) => r.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(","))
      .join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "relaymgr-hosts-" + new Date().toISOString().slice(0, 10) + ".csv";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast("已导出 " + state.hosts.length + " 台主机");
  }

  // ---------- 本机端口 ----------

  async function loadLocalPorts() {
    try {
      const d = await api("/api/localports");
      state.localPorts = d.ports || [];
      state.localDocker = d.dockerCount || 0;
      state.localApps = d.appCount || 0;
      renderLocalPorts();
    } catch (e) {
      $("#localSum").textContent = "读取失败：" + e.message;
    }
  }

  function localMatches(p) {
    const q = ($("#localFilter").value || "").trim().toLowerCase();
    if (!q) return true;
    return [String(p.port), p.addr, p.owner, p.process, p.detail, p.kind]
      .filter(Boolean).join(" ").toLowerCase().includes(q);
  }

  function localKindTag(kind) {
    const map = {
      docker: ["Docker", "tag"],
      app: ["飞牛应用", "tag self"],
      system: ["系统", "tag"],
      unknown: ["未知", "tag"],
    };
    const m = map[kind] || map.unknown;
    return el("span", m[1], m[0]);
  }

  function renderLocalPorts() {
    const tbody = $("#localRows");
    tbody.innerHTML = "";
    const list = (state.localPorts || []).filter(localMatches);
    list.forEach((p) => {
      const tr = document.createElement("tr");
      tr.appendChild(el("td", "mono", String(p.port)));
      tr.appendChild(el("td", "mono cell-sub-wrap", p.addr || "—"));

      const kindTd = el("td", "tag-cell");
      kindTd.appendChild(localKindTag(p.kind));
      tr.appendChild(kindTd);

      const nameTd = el("td", "");
      nameTd.appendChild(el("div", "cell-name", p.owner || "—"));
      if (p.pid) nameTd.appendChild(el("div", "cell-sub", "PID " + p.pid + " · " + (p.process || "")));
      tr.appendChild(nameTd);

      tr.appendChild(el("td", "cell-sub-wrap", p.detail || "—"));

      const act = el("td", "right");
      if (p.kind !== "unknown" || p.port > 0) {
        act.appendChild(miniBtn("转发 " + p.port, "", () => forwardLocalPort(p)));
      }
      tr.appendChild(act);
      tbody.appendChild(tr);
    });

    $("#localSum").textContent = "监听 " + (state.localPorts || []).length + " 个端口 · Docker " +
      state.localDocker + " 个 · 飞牛应用 " + state.localApps + " 个 / 显示 " + list.length;
    $("#localEmpty").classList.toggle("hidden", list.length > 0);
  }

  function forwardLocalPort(p) {
    openModal(null);
    const lan = (state.interfaces[0] && state.interfaces[0].addr4) || "127.0.0.1";
    $("#fName").value = (p.owner || "本机") + " · " + p.port;
    $("#fListen").value = nextFreeListen(p.port + 10000);
    $("#fTargetHost").value = lan;
    $("#fTargetPort").value = p.port;
    setProto(p.proto && p.proto.startsWith("udp") ? "udp" : "tcp");
  }

  function nextFreeListen(preferred) {
    const used = new Set(state.forwards.map((f) => Number(f.listen)));
    let p = preferred || 13389;
    while (used.has(p) && p < 65535) p++;
    return p;
  }

  function quickForward(host, port) {
    openModal(null);
    $("#fName").value = (host.hostname || host.ip) + " · " + port;
    $("#fListen").value = nextFreeListen(port + 10000);
    $("#fTargetHost").value = host.ip;
    $("#fTargetPort").value = port;
    setProto("tcp");
  }

  function fmtDur(ms) {
    if (!ms || ms < 0) return "0s";
    if (ms < 1000) return ms + "ms";
    const sec = ms / 1000;
    if (sec < 60) return sec.toFixed(1) + "s";
    return Math.floor(sec / 60) + "m" + Math.round(sec % 60) + "s";
  }

  function renderScanStatus() {
    const st = state.scan;
    if (!st) return;
    const btn = $("#scanBtn");
    const stop = $("#scanStopBtn");
    const meta = $("#scanMeta");
    if (st.running) {
      const stopping = (st.phase || "").indexOf("正在停止") >= 0;
      btn.disabled = true;
      btn.textContent = stopping ? "停止中…" : "扫描中…";
      stop.classList.remove("hidden");
      stop.disabled = stopping;
      stop.textContent = stopping ? "正在停止…" : "停止";
      const pct = st.percent || 0;
      $("#scanState").textContent = (st.phase || "扫描中") + " " + pct + "%";
      $("#scanBar").style.width = pct + "%";
      $("#scanProgress").classList.remove("hidden");
      meta.classList.remove("hidden");
      const started = st.startedAt ? new Date(st.startedAt).getTime() : 0;
      const elapsed = st.elapsedMs || (started ? Date.now() - started : 0);
      const bits = ["已探测 " + st.done + " / " + st.total];
      if (st.conc) bits.push("并发 " + st.conc);
      if (st.currentIp) bits.push("当前 " + st.currentIp);
      bits.push("发现 " + st.found + " 台");
      bits.push("档位 " + (st.profile || "标准"));
      bits.push("已用 " + fmtDur(elapsed));
      meta.textContent = bits.join(" · ");
    } else {
      btn.disabled = false;
      btn.textContent = "开始扫描";
      stop.classList.add("hidden");
      $("#scanProgress").classList.add("hidden");
      meta.classList.add("hidden");
      $("#scanNote").classList.toggle("hidden", !st.note);
      $("#scanNote").textContent = st.note || "";
      if (st.error) {
        $("#scanState").textContent = "扫描失败：" + st.error;
        return;
      }
      const finished = st.finishedAt && new Date(st.finishedAt).getFullYear() > 2000;
      if (!finished) {
        $("#scanState").textContent = "空闲";
        return;
      }
      const bits = [];
      bits.push(st.canceled ? "已手动停止" : "上次扫描完成");
      bits.push(st.cidr || "—");
      if (st.found && st.found !== state.hosts.length) bits.push("本轮 " + st.found + " 台");
      bits.push("共 " + state.hosts.length + " 台");
      if (st.newCount) bits.push("新增 " + st.newCount);
      if (st.goneCount) bits.push("消失 " + st.goneCount);
      bits.push("耗时 " + fmtDur(st.elapsedMs));
      $("#scanState").textContent = bits.join(" · ");
    }
  }

  function scanRange() {
    // 起始 + 结束拼成后端认识的范围；结束留空就是单个地址。
    const a = $("#scanStart").value.trim();
    const b = $("#scanEnd").value.trim();
    if (!a) return "";
    if (!b) return a;
    if (a.includes("/") || a.includes("-") || /[,;，、]/.test(a)) return a;
    return a + "-" + b;
  }

  async function startScan() {
    const cidr = scanRange();
    if (!cidr) { toast("请填写起始 IP 或网段", true); return; }
    const profile = $("#scanProfile").value;
    const ports = $("#scanPorts").value.trim();
    if (profile === "custom" && !ports) {
      toast("自定义档位需要填写端口，例如 3389,8080 或 8000-8100", true);
      return;
    }
    if (profile === "full" && /[\/,;\-]/.test(cidr)) {
      toast("全端口扫描只支持单个 IP，把结束 IP 留空，起始填一个地址", true);
      return;
    }
    try {
      const r = await api("/api/scan", {
        method: "POST",
        body: {
          cidr,
          profile,
          ports,
          speed: $("#scanSpeed").value,
          usePing: $("#optPing").checked,
          forcePort: $("#optForce").checked,
          checkSMB: $("#optSMB").checked,
        },
      });
      state.scan = r.status;
      renderScanStatus();
      clearInterval(state.scanTimer);
      state.scanTimer = setInterval(pollScan, 1200);
    } catch (e) {
      toast(e.message, true);
    }
  }

  async function stopScan() {
    const stop = $("#scanStopBtn");
    stop.disabled = true;
    stop.textContent = "正在停止…";
    try {
      await api("/api/scan/stop", { method: "POST", body: {} });
      if (state.scan) state.scan.phase = "正在停止";
      renderScanStatus();
      // 扫描还在收尾，这里不拉 hosts：等 pollScan 收到 running=false 再统一刷新，
      // 否则会把上一轮的旧结果显示成“已停止”的结果。
    } catch (e) {
      stop.disabled = false;
      stop.textContent = "停止";
      toast(e.message, true);
    }
  }

  async function pollScan() {
    try {
      const r = await api("/api/scan/status");
      state.scan = r.status;
      renderScanStatus();
      if (!r.status.running) {
        clearInterval(state.scanTimer);
        state.scanTimer = null;
        const h = await api("/api/hosts");
        state.hosts = h.hosts || [];
        renderHosts();
        renderScanStatus();
        const bits = ["扫描" + (r.status.canceled ? "已停止" : "完成") + "，发现 " + state.hosts.length + " 台主机"];
        if (r.status.newCount) bits.push("新增 " + r.status.newCount);
        if (r.status.goneCount) bits.push("消失 " + r.status.goneCount);
        toast(bits.join("，"));
      }
    } catch (e) {
      clearInterval(state.scanTimer);
      state.scanTimer = null;
      toast(e.message, true);
    }
  }

  // ---------- 设置 ----------

  function fillSettings() {
    api("/api/settings").then((s) => {
      $("#setPort").value = s.listenPort || s.port;
      $("#setAllow").value = (s.allowCidr || []).join("\n");
      $("#setTimeout").value = s.scanTimeoutMs;
      $("#setTheme").value = document.documentElement.getAttribute("data-theme") || "teal";
      document.querySelectorAll("#stackSegment button").forEach((b) => {
        b.classList.toggle("active", b.dataset.stack === (s.ipv6 ? "dual" : "v4"));
      });
      state.net = Object.assign({}, state.net || {}, {
        port: s.port, listenPort: s.listenPort || s.port, ipv6: s.ipv6,
        listenMode: s.listenMode, addrs4: s.addrs4 || [], addrs6: s.addrs6 || [],
      });
      renderNetInfo();
    }).catch(() => {});
  }

  function bindTheme() {
    const sel = $("#setTheme");
    if (!sel) return;
    sel.value = document.documentElement.getAttribute("data-theme") || "teal";
    sel.addEventListener("change", () => applyTheme(sel.value));
  }

  async function saveSettings() {
    const allow = $("#setAllow").value.split("\n").map((x) => x.trim()).filter(Boolean);
    const activeBtn = document.querySelector("#stackSegment button.active");
    const useV6 = activeBtn ? activeBtn.dataset.stack === "dual" : true;
    const oldPort = (state.net && state.net.port) || 0;
    try {
      const r = await api("/api/settings", {
        method: "POST",
        body: {
          port: Number($("#setPort").value),
          ipv6: useV6,
          allowCidr: allow,
          scanTimeoutMs: Number($("#setTimeout").value),
        },
      });
      const note = $("#settingsNote");
      note.textContent = r.notice || "已保存";
      note.classList.remove("warn");
      if (r.port && oldPort && r.port !== oldPort) {
        toast("管理端口已切到 " + r.port + "，请用新端口重新打开管理界面");
      } else {
        toast(r.notice || "设置已保存");
      }
      if (r.warning) {
        // 新白名单不包含当前来源：明确提示，避免用户以为保存失败或直接失联。
        note.textContent = r.warning;
        note.classList.add("warn");
        toast(r.warning, true);
      }
      fillSettings();
    } catch (e) {
      const note = $("#settingsNote");
      note.textContent = e.message;
      note.classList.add("warn");
      toast(e.message, true);
    }
  }

  async function savePassword() {
    const oldPwd = $("#pwdOld").value.trim();
    const newPwd = $("#pwdNew").value.trim();
    const newPwd2 = $("#pwdNew2").value.trim();
    if (newPwd.length < 8) { toast("新口令至少 8 位", true); return; }
    if (newPwd !== newPwd2) { toast("两次输入的新口令不一致", true); return; }
    try {
      await api("/api/password", { method: "POST", body: { old: oldPwd, new: newPwd } });
      $("#pwdOld").value = ""; $("#pwdNew").value = ""; $("#pwdNew2").value = "";
      $("#pwdNote").textContent = "口令已更新";
      toast("口令已更新");
    } catch (e) {
      toast(e.message, true);
    }
  }

  // ---------- 审计 ----------

  async function loadAudit() {
    try {
      const r = await api("/api/audit?limit=120");
      const tbody = $("#auditRows");
      tbody.innerHTML = "";
      (r.entries || []).forEach((e) => {
        const tr = document.createElement("tr");
        tr.appendChild(el("td", "mono", fmtTime(e.time)));
        tr.appendChild(el("td", "mono", e.ip || "—"));
        tr.appendChild(el("td", "", e.action));
        tr.appendChild(el("td", "", e.detail));
        const td = el("td", "", e.result);
        if (e.result === "成功" || e.result === "开始") td.style.color = "var(--green)";
        else if (e.result === "失败" || e.result === "拒绝") td.style.color = "var(--red)";
        else td.style.color = "var(--muted)";
        tr.appendChild(td);
        tbody.appendChild(tr);
      });
      $("#auditEmpty").classList.toggle("hidden", (r.entries || []).length > 0);
    } catch (e) { toast(e.message, true); }
  }

  // ---------- 视图切换 ----------

  function switchView(view) {
    state.view = view;
    document.querySelectorAll(".view").forEach((v) => {
      v.classList.toggle("hidden", v.id !== "view-" + view);
    });
    document.querySelectorAll(".nav-item").forEach((b) => {
      b.classList.toggle("active", b.dataset.view === view);
    });
    if (view === "audit") loadAudit();
    if (view === "discover") { renderInterfaces(); renderScanStatus(); }
    if (view === "settings") fillSettings();
    if (view === "localports") loadLocalPorts();
  }

  // ---------- 轮询 ----------

  function startPolling() {
    stopPolling();
    state.pollTimer = setInterval(async () => {
      try {
        const s = await api("/api/state");
        if (!s.authed) { showGate("login"); return; }
        applyState(s);
        if (state.view === "discover" && state.scan && state.scan.running) renderScanStatus();
      } catch (e) {
        if (e.status === 401) showGate("login");
      }
    }, 5000);
  }

  function stopPolling() {
    if (state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = null;
  }

  // ---------- 事件绑定 ----------

  $("#loginBtn").addEventListener("click", doLogin);
  $("#loginPwd").addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });
  $("#setupBtn").addEventListener("click", doSetup);
  $("#logoutBtn").addEventListener("click", doLogout);

  $("#nav").addEventListener("click", (e) => {
    const btn = e.target.closest(".nav-item");
    if (btn) switchView(btn.dataset.view);
  });

  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-open-new]")) openModal(null);
    const goto = e.target.closest("[data-goto]");
    if (goto) switchView(goto.dataset.goto);
  });

  $("#modalClose").addEventListener("click", closeModal);
  $("#modalCancel").addEventListener("click", closeModal);
  $("#modalSave").addEventListener("click", saveForward);
  $("#modal").addEventListener("click", (e) => { if (e.target === $("#modal")) closeModal(); });
  document.querySelectorAll("#protoSeg button").forEach((b) => {
    b.addEventListener("click", () => setProto(b.dataset.proto));
  });
  document.querySelectorAll(".chip").forEach((b) => {
    b.addEventListener("click", () => applyTemplate(b.dataset.template));
  });

  updateFullHint();
  $("#scanBtn").addEventListener("click", startScan);
  $("#scanStopBtn").addEventListener("click", stopScan);
  function updateFullHint() {
    const profile = $("#scanProfile").value;
    $("#customPortsField").classList.toggle("hidden", profile !== "custom");
    $("#scanProfileNote").classList.toggle("hidden", profile !== "full");
    if (profile !== "full") return;
    const concMap = { fast: 256, medium: 128, slow: 48 };
    const conc = concMap[$("#scanSpeed").value] || 128;
    const ms = state.scanTimeoutMs || 300;
    const sec = Math.round((65535 * ms) / 1000 / conc);
    $("#scanProfileNote").textContent = "全端口会向目标连续发起 65535 次连接，可能触发目标侧的扫描防护，仅对自己的设备使用。按 " +
      ms + "ms 超时、并发 " + conc + " 估算最长约 " + fmtDur(sec * 1000) +
      (conc >= 128 ? "；ESP、单片机等弱设备建议改用慢速" : "");
  }

  $("#scanProfile").addEventListener("change", updateFullHint);
  $("#scanSpeed").addEventListener("change", updateFullHint);
  $("#scanView").addEventListener("change", (e) => {
    state.scanView = e.target.value;
    renderHosts();
  });
  $("#exportBtn").addEventListener("click", exportHosts);
  $("#localRefreshBtn").addEventListener("click", loadLocalPorts);
  $("#localFilter").addEventListener("input", renderLocalPorts);
  $("#hostFilter").addEventListener("input", (e) => {
    state.hostQuery = e.target.value;
    renderHosts();
  });
  $("#onlyRisk").addEventListener("change", (e) => {
    state.onlyRisk = e.target.checked;
    renderHosts();
  });
  $("#onlyNew").addEventListener("change", (e) => {
    state.onlyNew = e.target.checked;
    renderHosts();
  });
  $("#scanStart").addEventListener("change", updateFullHint);
  document.querySelectorAll("#stackSegment button").forEach((b) => {
    b.addEventListener("click", () => {
      document.querySelectorAll("#stackSegment button").forEach((x) => {
        x.classList.toggle("active", x === b);
      });
    });
  });
  $("#saveSettings").addEventListener("click", saveSettings);
  $("#savePwd").addEventListener("click", savePassword);
  $("#refreshAudit").addEventListener("click", loadAudit);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !$("#modal").classList.contains("hidden")) closeModal();
  });

  boot();
  document.addEventListener("DOMContentLoaded", bindTheme);
})();
