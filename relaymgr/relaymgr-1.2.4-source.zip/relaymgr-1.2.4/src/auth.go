package main

// 认证：PBKDF2 口令、会话、登录失败锁定与限速。
// 设计要点：不设「初始化口令」。首次初始化只允许局域网来源，或由 NAS 上的
// 命令行（relaymgr --set-password -）直接设置，公网无法抢先初始化。

import (
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sync"
	"time"
)

const (
	sessionTTL = 12 * time.Hour

	// 同一来源连续失败达到该次数后开始锁定，之后每次失败锁定时长翻倍。
	lockAfterFails = 5
	lockBase       = 15 * time.Minute
	lockMax        = 24 * time.Hour

	// 全站登录尝试限速：窗口内超过上限后短暂拦截，用来对抗换 IP 的代理池。
	globalWindow   = time.Minute
	globalMaxTry   = 20
	globalCoolDown = 3 * time.Minute
)

var (
	ErrRateLimited = errors.New("登录请求过于频繁，请稍后再试")
	ErrLocked      = errors.New("登录已锁定")
)

type failState struct {
	Count       int       `json:"count"`
	LockedUntil time.Time `json:"lockedUntil"`
}

type ticketFile struct {
	IPs map[string]*failState `json:"ips"`
}

type Auth struct {
	store    *Store
	audit    *Audit
	mu       sync.Mutex
	sessions map[string]time.Time
	fails    map[string]*failState
	lockPath string

	windowStart time.Time
	windowCount int
	blockedTill time.Time
}

func NewAuth(store *Store, audit *Audit, dataDir string) *Auth {
	a := &Auth{
		store:    store,
		audit:    audit,
		sessions: map[string]time.Time{},
		fails:    map[string]*failState{},
		lockPath: filepath.Join(dataDir, "login-guard.json"),
	}
	a.load()
	// 清理旧版本留下的初始化口令文件
	_ = os.Remove(filepath.Join(dataDir, "setup-code.txt"))
	go a.reap()
	return a
}

// load 恢复锁定期记录：重启不能成为清零失败次数的捷径。
func (a *Auth) load() {
	b, err := os.ReadFile(a.lockPath)
	if err != nil {
		return
	}
	var tf ticketFile
	if err := json.Unmarshal(b, &tf); err != nil {
		return
	}
	now := time.Now()
	for ip, f := range tf.IPs {
		if f == nil {
			continue
		}
		if !f.LockedUntil.IsZero() && f.LockedUntil.After(now.Add(lockMax)) {
			f.LockedUntil = now.Add(lockMax)
		}
		// 已过期且计数很小的记录不再保留
		if f.LockedUntil.IsZero() && f.Count < lockAfterFails {
			continue
		}
		a.fails[ip] = f
	}
}

// persist 调用方需持有锁。
func (a *Auth) persist() {
	tf := ticketFile{IPs: a.fails}
	b, err := json.Marshal(tf)
	if err != nil {
		return
	}
	_ = os.WriteFile(a.lockPath, b, 0o600)
}

func (a *Auth) reap() {
	tk := time.NewTicker(10 * time.Minute)
	defer tk.Stop()
	for range tk.C {
		now := time.Now()
		a.mu.Lock()
		for t, exp := range a.sessions {
			if now.After(exp) {
				delete(a.sessions, t)
			}
		}
		for ip, f := range a.fails {
			if f.LockedUntil.IsZero() && f.Count == 0 {
				delete(a.fails, ip)
			}
		}
		a.mu.Unlock()
	}
}

func (a *Auth) Initialized() bool { return a.store.Initialized() }

// LockRemain 返回该来源还需要等待的秒数，0 表示未锁定。
func (a *Auth) LockRemain(ip string) int {
	a.mu.Lock()
	defer a.mu.Unlock()
	if f := a.fails[ip]; f != nil && time.Now().Before(f.LockedUntil) {
		return int(time.Until(f.LockedUntil).Seconds()) + 1
	}
	return 0
}

// lockDuration 第 n 次失败对应的锁定时长：15m、30m、60m…上限 24h。
func lockDuration(count int) time.Duration {
	if count < lockAfterFails {
		return 0
	}
	d := lockBase
	for i := lockAfterFails; i < count; i++ {
		d *= 2
		if d >= lockMax {
			return lockMax
		}
	}
	if d > lockMax {
		d = lockMax
	}
	return d
}

// Setup 首次初始化：任何来源都可以直接设置管理口令。
// 一旦设置完成就永久锁定为登录页，不会再暴露初始化入口。
func (a *Auth) Setup(password, ip string) error {
	if a.Initialized() {
		return errors.New("应用已完成初始化")
	}
	if err := a.store.SetPassword(password); err != nil {
		return err
	}
	a.audit.Append(ip, "setup", "完成初始化并设置管理口令", "成功")
	return nil
}

func (a *Auth) Login(password, ip string) (string, error) {
	now := time.Now()

	a.mu.Lock()
	f := a.fails[ip]
	if f == nil {
		f = &failState{}
		a.fails[ip] = f
	}
	// 已锁定直接拒绝，且不占用全局尝试额度
	if now.Before(f.LockedUntil) {
		remain := int(time.Until(f.LockedUntil).Seconds()) + 1
		a.mu.Unlock()
		return "", fmt.Errorf("%w，请 %s后再试", ErrLocked, humanDuration(remain))
	}

	// 全局限速：不论来自多少个 IP，整体尝试频率都要压住
	if now.Before(a.blockedTill) {
		remain := int(time.Until(a.blockedTill).Seconds()) + 1
		a.mu.Unlock()
		return "", fmt.Errorf("%w，请 %s后再试", ErrRateLimited, humanDuration(remain))
	}
	if now.Sub(a.windowStart) > globalWindow {
		a.windowStart = now
		a.windowCount = 0
	}
	a.windowCount++
	if a.windowCount > globalMaxTry {
		a.blockedTill = now.Add(globalCoolDown)
		a.windowCount = 0
		a.mu.Unlock()
		a.audit.Append(ip, "login", "全站登录尝试超限，已临时拦截", "拒绝")
		return "", fmt.Errorf("%w，请 %s后再试", ErrRateLimited, humanDuration(int(globalCoolDown.Seconds())))
	}

	attempt := f.Count
	a.mu.Unlock()

	if !a.store.CheckPassword(password) {
		a.mu.Lock()
		// 重新取状态，避免并发下用旧值
		f = a.fails[ip]
		if f == nil {
			f = &failState{}
			a.fails[ip] = f
		}
		f.Count++
		d := lockDuration(f.Count)
		if d > 0 {
			f.LockedUntil = time.Now().Add(d)
		}
		remain := f.Count
		a.persist()
		a.mu.Unlock()

		a.audit.Append(ip, "login", fmt.Sprintf("管理口令错误（连续第 %d 次）", remain), "失败")

		// 逐步加长响应时间，拖慢自动化爆破
		delay := time.Duration(attempt) * 150 * time.Millisecond
		if delay > 1200*time.Millisecond {
			delay = 1200 * time.Millisecond
		}
		if delay > 0 {
			time.Sleep(delay)
		}

		if d > 0 {
			return "", fmt.Errorf("口令错误，失败次数过多，已锁定 %s", humanDuration(int(d.Seconds())))
		}
		left := lockAfterFails - f.Count
		return "", fmt.Errorf("口令不正确，再失败 %d 次将锁定", left)
	}

	token := randomHex(24)
	a.mu.Lock()
	a.sessions[token] = time.Now().Add(sessionTTL)
	a.fails[ip] = &failState{}
	a.persist()
	a.mu.Unlock()
	a.audit.Append(ip, "login", "登录管理界面", "成功")
	return token, nil
}

func (a *Auth) Valid(token string) bool {
	if token == "" {
		return false
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	exp, ok := a.sessions[token]
	if !ok {
		return false
	}
	if time.Now().After(exp) {
		delete(a.sessions, token)
		return false
	}
	return true
}

func (a *Auth) Logout(token string) {
	a.mu.Lock()
	delete(a.sessions, token)
	a.mu.Unlock()
}

func (a *Auth) ChangePassword(oldPwd, newPwd, ip, keepToken string) error {
	if !a.store.CheckPassword(oldPwd) {
		a.audit.Append(ip, "password", "修改口令失败：原口令错误", "失败")
		return errors.New("原口令不正确")
	}
	if err := a.store.SetPassword(newPwd); err != nil {
		return err
	}
	// 换口令后让其它会话立即失效，只保留当前这个，防止旧 cookie 继续用 12 小时。
	a.mu.Lock()
	for t := range a.sessions {
		if t != keepToken {
			delete(a.sessions, t)
		}
	}
	a.mu.Unlock()
	a.audit.Append(ip, "password", "修改管理口令，其它会话已失效", "成功")
	return nil
}

func humanDuration(sec int) string {
	if sec < 60 {
		return fmt.Sprintf("%d 秒", sec)
	}
	if sec < 3600 {
		if sec%60 == 0 {
			return fmt.Sprintf("%d 分钟", sec/60)
		}
		return fmt.Sprintf("%d 分 %d 秒", sec/60, sec%60)
	}
	if sec%3600 == 0 {
		return fmt.Sprintf("%d 小时", sec/3600)
	}
	return fmt.Sprintf("%d 小时 %d 分", sec/3600, (sec%3600)/60)
}

// ---- 网络工具 ----

func isPrivateIP(ip net.IP) bool {
	if ip == nil {
		return false
	}
	return ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast()
}
