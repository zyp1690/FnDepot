package main

// 本机端口：读取 /proc/net 的监听表，并把端口归到 Docker 容器、飞牛应用或具体进程。

import (
	"bufio"
	"context"
	"encoding/hex"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type LocalPort struct {
	Port    int    `json:"port"`
	Proto   string `json:"proto"`
	Addr    string `json:"addr"`
	PID     int    `json:"pid,omitempty"`
	Process string `json:"process,omitempty"`
	Kind    string `json:"kind"`
	Owner   string `json:"owner,omitempty"`
	Detail  string `json:"detail,omitempty"`
}

type localPortsResult struct {
	Ports     []LocalPort `json:"ports"`
	Docker    int         `json:"dockerCount"`
	Apps      int         `json:"appCount"`
	Generated string      `json:"generated"`
}

type dockerMapping struct {
	HostPort  int
	Container string
	Image     string
	Target    string
}

type appMapping struct {
	Port int
	Name string
	Path string
}

// socketOwner 遍历 /proc/<pid>/fd，把 socket inode 映射到进程。
func socketOwner() map[string][2]string {
	out := map[string][2]string{}
	dirs, err := filepath.Glob("/proc/[0-9]*")
	if err != nil {
		return out
	}
	links := 0
	for _, dir := range dirs {
		pid := filepath.Base(dir)
		name := ""
		if b, err := os.ReadFile(filepath.Join(dir, "comm")); err == nil {
			name = strings.TrimSpace(string(b))
		}
		fds, err := filepath.Glob(filepath.Join(dir, "fd", "*"))
		if err != nil {
			continue
		}
		for _, fd := range fds {
			if links++; links > 30000 {
				return out
			}
			link, err := os.Readlink(fd)
			if err != nil || !strings.HasPrefix(link, "socket:[") {
				continue
			}
			inode := strings.TrimSuffix(strings.TrimPrefix(link, "socket:["), "]")
			out[inode] = [2]string{pid, name}
		}
	}
	return out
}

func procListenPorts() map[string]struct {
	Port  int
	Proto string
	Addr  string
} {
	res := map[string]struct {
		Port  int
		Proto string
		Addr  string
	}{}
	files := []struct {
		path  string
		proto string
	}{
		{"/proc/net/tcp", "tcp"},
		{"/proc/net/tcp6", "tcp"},
		{"/proc/net/udp", "udp"},
		{"/proc/net/udp6", "udp"},
	}
	for _, f := range files {
		fh, err := os.Open(f.path)
		if err != nil {
			continue
		}
		sc := bufio.NewScanner(fh)
		sc.Scan() // 表头
		for sc.Scan() {
			fields := strings.Fields(sc.Text())
			if len(fields) < 10 {
				continue
			}
			local := fields[1]
			state := fields[3]
			inode := fields[9]
			if f.proto == "tcp" && state != "0A" {
				continue
			}
			parts := strings.Split(local, ":")
			if len(parts) != 2 {
				continue
			}
			portNum, err := strconv.ParseInt(parts[1], 16, 32)
			if err != nil || portNum <= 0 {
				continue
			}
			addr := hexAddrToIP(parts[0])
			key := f.proto + ":" + strconv.FormatInt(portNum, 10) + ":" + inode
			res[key] = struct {
				Port  int
				Proto string
				Addr  string
			}{int(portNum), f.proto, addr}
		}
		fh.Close()
	}
	return res
}

// hexAddrToIP 把 /proc/net 里的十六进制地址转成可读形式。
func hexAddrToIP(s string) string {
	switch len(s) {
	case 8:
		b := make([]byte, 4)
		for i := 0; i < 4; i++ {
			v, _ := strconv.ParseUint(s[i*2:i*2+2], 16, 8)
			b[3-i] = byte(v)
		}
		if b[0] == 0 && b[1] == 0 && b[2] == 0 && b[3] == 0 {
			return "0.0.0.0"
		}
		return strings.Join([]string{strconv.Itoa(int(b[0])), strconv.Itoa(int(b[1])), strconv.Itoa(int(b[2])), strconv.Itoa(int(b[3]))}, ".")
	case 32:
		if strings.Trim(s, "0") == "" {
			return "::"
		}
		return "IPv6"
	default:
		return "—"
	}
}

// dockerPorts 解析 docker ps 的端口映射，拿宿主端口对应的容器。
func dockerPorts() []dockerMapping {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	out, err := exec.CommandContext(ctx, "docker", "ps", "--no-trunc",
		"--format", "{{.Names}}\t{{.Image}}\t{{.Ports}}").Output()
	if err != nil {
		return nil
	}
	list := []dockerMapping{}
	for _, line := range strings.Split(strings.TrimSpace(string(out)), "\n") {
		if line == "" {
			continue
		}
		parts := strings.Split(line, "\t")
		if len(parts) < 3 {
			continue
		}
		name, image, ports := parts[0], parts[1], parts[2]
		for _, seg := range strings.Split(ports, ",") {
			seg = strings.TrimSpace(seg)
			arrow := strings.Index(seg, "->")
			if arrow < 0 {
				continue
			}
			bind := seg[:arrow]
			target := strings.TrimSpace(seg[arrow+2:])
			idx := strings.LastIndex(bind, ":")
			if idx < 0 {
				continue
			}
			hostPort, err := strconv.Atoi(bind[idx+1:])
			if err != nil {
				continue
			}
			list = append(list, dockerMapping{HostPort: hostPort, Container: name, Image: image, Target: target})
		}
	}
	return list
}

// fnosApps 扫描飞牛应用的 manifest，拿应用显示名与服务端口。
func fnosApps() []appMapping {
	list := []appMapping{}
	// 环境变量仅用于本地验证，线上默认扫飞牛的两个标准位置。
	globs := []string{"/var/apps/*/manifest", "/vol*/@appstore/*/manifest"}
	if custom := os.Getenv("RELAYMGR_APP_GLOB"); custom != "" {
		globs = strings.Split(custom, ":")
	}
	for _, g := range globs {
		paths, err := filepath.Glob(g)
		if err != nil {
			continue
		}
		for _, p := range paths {
			b, err := os.ReadFile(p)
			if err != nil || len(b) > 1<<20 {
				continue
			}
			name, portStr := "", ""
			for _, line := range strings.Split(string(b), "\n") {
				line = strings.TrimSpace(line)
				switch {
				case strings.HasPrefix(line, "display_name=") && name == "":
					name = strings.TrimPrefix(line, "display_name=")
				case strings.HasPrefix(line, "service_port="):
					portStr = strings.TrimPrefix(line, "service_port=")
				}
			}
			port, err := strconv.Atoi(strings.TrimSpace(portStr))
			if err != nil || port <= 0 || name == "" {
				continue
			}
			list = append(list, appMapping{Port: port, Name: name, Path: filepath.Dir(p)})
		}
	}
	return list
}

// collectLocalPorts 汇总本机监听端口与归属信息。
func collectLocalPorts() localPortsResult {
	raw := procListenPorts()
	owners := socketOwner()
	docker := dockerPorts()
	apps := fnosApps()

	dockerByPort := map[int][]dockerMapping{}
	for _, d := range docker {
		dockerByPort[d.HostPort] = append(dockerByPort[d.HostPort], d)
	}
	appByPort := map[string]appMapping{}
	for _, a := range apps {
		appByPort[strconv.Itoa(a.Port)] = a
	}

	type agg struct {
		entry  LocalPort
		addrs  []string
		protos []string
	}
	byPort := map[int]*agg{}
	for key, v := range raw {
		inode := key[strings.LastIndex(key, ":")+1:]
		a, ok := byPort[v.Port]
		if !ok {
			a = &agg{entry: LocalPort{Port: v.Port}}
			byPort[v.Port] = a
		}
		if !strings.Contains(strings.Join(a.addrs, ","), v.Addr) {
			a.addrs = append(a.addrs, v.Addr)
		}
		if !strings.Contains(strings.Join(a.protos, ","), v.Proto) {
			a.protos = append(a.protos, v.Proto)
		}
		if pid, ok := owners[inode]; ok {
			if a.entry.PID == 0 {
				a.entry.PID, _ = strconv.Atoi(pid[0])
				a.entry.Process = pid[1]
			}
		}
	}

	ssMap := map[int][2]string{}
	out := make([]LocalPort, 0, len(byPort))
	for port, a := range byPort {
		if a.entry.Process == "" {
			if ssMap == nil || len(ssMap) == 0 {
				ssMap = ssOwners()
			}
			if pid, ok := ssMap[port]; ok {
				a.entry.PID, _ = strconv.Atoi(pid[0])
				a.entry.Process = pid[1]
			}
		}
		e := a.entry
		e.Addr = strings.Join(a.addrs, " / ")
		e.Proto = strings.Join(a.protos, "/")
		switch {
		case len(dockerByPort[port]) > 0:
			d := dockerByPort[port][0]
			e.Kind = "docker"
			e.Owner = d.Container
			e.Detail = d.Image + " · 容器 " + d.Target
		case appByPort[strconv.Itoa(port)].Name != "":
			ap := appByPort[strconv.Itoa(port)]
			e.Kind = "app"
			e.Owner = ap.Name
			e.Detail = "飞牛应用 · " + ap.Path
		case e.Process != "":
			e.Kind = "system"
			e.Owner = e.Process
		default:
			e.Kind = "unknown"
		}
		out = append(out, e)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Port < out[j].Port })
	return localPortsResult{
		Ports:     out,
		Docker:    len(dockerByPort),
		Apps:      len(appByPort),
		Generated: time.Now().Format(time.RFC3339),
	}
}

// ssOwners 用 ss 命令兜底：无权限读别的用户的 /proc/<pid>/fd 时，
// 从 ss 的 users:(("name",pid=N,...)) 里拿进程归属。
func ssOwners() map[int][2]string {
	out := map[int][2]string{}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	b, err := exec.CommandContext(ctx, "ss", "-H", "-lntup").Output()
	if err != nil {
		return out
	}
	portRe := regexp.MustCompile(`:(\d{1,5})\s`)
	pidRe := regexp.MustCompile(`\("([^"]+)",pid=(\d+)`)
	for _, line := range strings.Split(string(b), "\n") {
		m := portRe.FindStringSubmatch(line)
		if len(m) < 2 {
			continue
		}
		pm := pidRe.FindStringSubmatch(line)
		if len(pm) < 3 {
			continue
		}
		port, err := strconv.Atoi(m[1])
		if err != nil {
			continue
		}
		if _, ok := out[port]; !ok {
			out[port] = [2]string{pm[2], pm[1]}
		}
	}
	return out
}

var _ = hex.EncodeToString
