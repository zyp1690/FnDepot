package main

// 网络绑定与地址探测。
// 管理端口和转发端口统一走双栈绑定：优先 [::]（同时接受 IPv4/IPv6），
// 系统未启用 IPv6 时自动回退 0.0.0.0，并在界面上如实显示当前协议栈。

import (
	"fmt"
	"net"
	"sort"
)

const (
	modeDual = "IPv4+IPv6"
	modeV4   = "仅 IPv4"
)

// bindTCP 监听 TCP 端口，返回 listener 与实际监听模式。
func bindTCP(port int, ipv6 bool) (net.Listener, string, error) {
	if ipv6 {
		if ln, err := net.Listen("tcp", fmt.Sprintf(":%d", port)); err == nil {
			return ln, tcpMode(ln.Addr()), nil
		}
	}
	// 用 tcp4 强制仅 IPv4：Go 对 "0.0.0.0" 在支持 IPv6 的系统上仍会开双栈 socket。
	ln, err := net.Listen("tcp4", fmt.Sprintf("0.0.0.0:%d", port))
	if err != nil {
		return nil, "", err
	}
	return ln, modeV4, nil
}

// bindUDP 监听 UDP 端口，返回 packet conn 与实际监听模式。
func bindUDP(port int, ipv6 bool) (net.PacketConn, string, error) {
	if ipv6 {
		if pc, err := net.ListenPacket("udp", fmt.Sprintf(":%d", port)); err == nil {
			return pc, tcpMode(pc.LocalAddr()), nil
		}
	}
	pc, err := net.ListenPacket("udp4", fmt.Sprintf("0.0.0.0:%d", port))
	if err != nil {
		return nil, "", err
	}
	return pc, modeV4, nil
}

// tcpMode 依据监听地址判断是否真的双栈。
func tcpMode(a net.Addr) string {
	if ta, ok := a.(*net.TCPAddr); ok && ta.IP.To4() == nil {
		return modeDual
	}
	return modeV4
}

// localAddrs 返回本机可用的 IPv4 / IPv6 地址（排除回环与 IPv6 链路本地）。
func localAddrs() ([]string, []string) {
	v4 := []string{}
	v6 := []string{}
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return v4, v6
	}
	for _, a := range addrs {
		ipnet, ok := a.(*net.IPNet)
		if !ok {
			continue
		}
		ip := ipnet.IP
		if ip.IsLoopback() {
			continue
		}
		if v := ip.To4(); v != nil {
			v4 = append(v4, v.String())
			continue
		}
		if ip.IsLinkLocalUnicast() {
			continue
		}
		v6 = append(v6, ip.String())
	}
	sort.Strings(v4)
	sort.Strings(v6)
	return v4, v6
}
