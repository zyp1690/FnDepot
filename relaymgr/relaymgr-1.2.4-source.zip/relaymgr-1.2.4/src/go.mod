module relaymgr

go 1.23
