package main

// 内网管家 · 飞牛 fnOS 原生应用
// 方案 D（公网直连）的落地实现：带口令的管理界面 + 可增删改的端口转发 + 内网主机发现。

import (
	"bufio"
	"context"
	"embed"
	"encoding/json"
	"flag"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

const AppVersion = "1.2.4"

//go:embed web
var embeddedWeb embed.FS

// httpService 持有当前管理界面的 listener，支持运行期切端口/切协议栈。
type httpService struct {
	srv  *http.Server
	mu   sync.Mutex
	ln   net.Listener
	mode string
	port int
	ipv6 bool
}

// start 绑定新监听并接管服务；成功后关闭旧 listener。
func (h *httpService) start(port int, ipv6 bool) (string, error) {
	// 绑定也在锁内：并发改端口时不会出现两个都绑成功、旧 listener 变孤儿的情况。
	h.mu.Lock()
	ln, mode, err := bindTCP(port, ipv6)
	if err != nil {
		h.mu.Unlock()
		return "", err
	}
	old := h.ln
	h.ln, h.mode, h.port, h.ipv6 = ln, mode, port, ipv6
	h.mu.Unlock()
	if old != nil {
		_ = old.Close()
	}
	go func(l net.Listener) { _ = h.srv.Serve(l) }(ln)
	return mode, nil
}

func (h *httpService) info() (int, bool, string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.port, h.ipv6, h.mode
}

func main() {
	defaultData := os.Getenv("TRIM_PKGVAR")
	if defaultData == "" {
		defaultData = "/tmp/relaymgr"
	}
	dataDir := flag.String("data-dir", defaultData, "运行数据目录")
	portFlag := flag.Int("port", 0, "管理界面端口（0 表示读取配置）")
	setPwd := flag.String("set-password", "", "设置或重置管理口令；传 - 从标准输入读取")
	uiFlag := flag.String("ui-config", "", "桌面入口配置（app/ui/config），改端口时同步")
	syncUI := flag.String("sync-ui-port", "", "只更新该 ui/config 的端口后退出（生命周期脚本用）")
	provision := flag.Bool("provision", false, "按安装向导的环境变量写入端口与协议栈（install_callback 用）")
	flag.Parse()

	log.SetFlags(log.LstdFlags)

	store, err := NewStore(*dataDir)
	if err != nil {
		log.Fatalf("初始化配置失败: %v", err)
	}

	// 生命周期脚本调用：把桌面入口的端口改成与运行配置一致，
	// 这样升级覆盖 target/ui/config 之后桌面图标仍然指向真实端口。
	if *syncUI != "" {
		p := *portFlag
		if p == 0 {
			p = store.Snapshot().Port
		}
		if p <= 0 || p > 65535 {
			log.Fatalf("--sync-ui-port 无法确定有效端口")
		}
		if err := syncUIConfig(*syncUI, p); err != nil {
			log.Fatalf("同步桌面入口端口失败: %v", err)
		}
		log.Printf("[relaymgr] 桌面入口端口已同步为 %d（%s）", p, *syncUI)
		return
	}

	// 安装向导填写的端口与协议栈（向导字段会变成 wizard_* 环境变量）。
	if *provision {
		port := 8899
		if v := strings.TrimSpace(os.Getenv("wizard_admin_port")); v != "" {
			if n, err := strconv.Atoi(v); err == nil && n >= 1024 && n <= 65535 {
				port = n
			} else {
				log.Printf("[relaymgr] 安装向导端口 %q 无效，回退 8899", v)
			}
		}
		ipv6 := true
		if v := strings.TrimSpace(os.Getenv("wizard_ipv6")); v != "" {
			ipv6 = !strings.EqualFold(v, "false")
		}
		if err := store.Update(func(cfg *Config) error {
			cfg.Port = port
			cfg.IPv6 = ipv6
			return nil
		}); err != nil {
			log.Fatalf("写入安装配置失败: %v", err)
		}
		log.Printf("[relaymgr] 安装配置已写入：端口 %d，IPv6 %v", port, ipv6)
		if *uiFlag != "" {
			if err := syncUIConfig(*uiFlag, port); err != nil {
				log.Printf("[relaymgr] 桌面入口端口同步失败: %v", err)
			}
		}
		return
	}

	log.Printf("[relaymgr] 启动 v%s，数据目录 %s", AppVersion, *dataDir)

	// 命令行设置口令：用于在没有浏览器/内网判定的场景初始化，或忘记口令后重置。
	if *setPwd != "" {
		pwd := *setPwd
		if pwd == "-" {
			line, rerr := bufio.NewReader(os.Stdin).ReadString('\n')
			if rerr != nil && line == "" {
				log.Fatalf("读取标准输入失败: %v", rerr)
			}
			pwd = strings.TrimRight(line, "\r\n")
		}
		if err := store.SetPassword(pwd); err != nil {
			log.Fatalf("设置口令失败: %v", err)
		}
		log.Printf("[relaymgr] 管理口令已更新（数据目录 %s）", *dataDir)
		return
	}
	audit := NewAudit(*dataDir)
	auth := NewAuth(store, audit, *dataDir)
	fwd := NewForwardManager(store, audit)
	disc := NewDiscovery(*dataDir)

	cfg := store.Snapshot()

	port := *portFlag
	if port == 0 {
		if env := os.Getenv("RELAY_APP_PORT"); env != "" {
			if v, err := strconv.Atoi(env); err == nil {
				port = v
			}
		}
	}
	if port == 0 {
		port = cfg.Port
	}
	if port == 0 {
		port = 8899
	}

	web, err := fs.Sub(embeddedWeb, "web")
	if err != nil {
		log.Fatalf("内嵌前端资源异常: %v", err)
	}

	fwd.Restore()
	srv := NewServer(store, auth, fwd, disc, audit)
	srv.web = web

	httpServer := &http.Server{
		Handler:           srv.Routes(),
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	svc := &httpService{srv: httpServer}
	mode, err := svc.start(port, cfg.IPv6)
	if err != nil {
		log.Fatalf("监听 %d 失败: %v", port, err)
	}
	log.Printf("[relaymgr] 管理界面监听 :%d（%s）", port, mode)

	// 交给 API 层：保存设置时可以直接切换端口/协议栈，无需重启应用。
	srv.listenInfo = svc.info
	srv.restart = func(p int, ipv6 bool) (string, error) {
		m, err := svc.start(p, ipv6)
		if err != nil {
			return "", err
		}
		if *uiFlag != "" {
			if err := syncUIConfig(*uiFlag, p); err != nil {
				log.Printf("[relaymgr] 桌面入口端口同步失败: %v", err)
			}
		}
		log.Printf("[relaymgr] 管理界面已切换到 :%d（%s）", p, m)
		return m, nil
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	done := make(chan struct{})
	go func() {
		<-stop
		log.Printf("[relaymgr] 收到停止信号，正在关闭")
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = httpServer.Shutdown(ctx)
		fwd.StopAll()
		close(done)
	}()

	<-done
	log.Printf("[relaymgr] 已退出")
}

// syncUIConfig 把 app/ui/config 里所有入口的 port 改成指定值，
// 让飞牛桌面图标始终指向真实的管理端口。
func syncUIConfig(path string, port int) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	var root map[string]map[string]map[string]any
	if err := json.Unmarshal(b, &root); err != nil {
		return fmt.Errorf("解析 %s 失败: %w", path, err)
	}
	entries, ok := root[".url"]
	if !ok || len(entries) == 0 {
		return fmt.Errorf("%s 中没有 .url 入口", path)
	}
	for _, e := range entries {
		e["port"] = strconv.Itoa(port)
	}
	out, err := json.MarshalIndent(root, "", "  ")
	if err != nil {
		return err
	}
	out = append(out, '\n')
	return os.WriteFile(path, out, 0o644)
}

// handleStatic 只暴露内嵌前端的少量文件，不暴露目录内容。
func (s *Server) handleStatic(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/")
	switch path {
	case "", "index.html":
		s.serveEmbedded(w, "index.html", "text/html; charset=utf-8")
	case "app.css":
		s.serveEmbedded(w, "app.css", "text/css; charset=utf-8")
	case "app.js":
		s.serveEmbedded(w, "app.js", "application/javascript; charset=utf-8")
	case "favicon.svg":
		s.serveEmbedded(w, "favicon.svg", "image/svg+xml")
	default:
		http.NotFound(w, r)
	}
}

func (s *Server) serveEmbedded(w http.ResponseWriter, name, ctype string) {
	b, err := fs.ReadFile(s.web, name)
	if err != nil {
		http.NotFound(w, nil)
		return
	}
	w.Header().Set("Content-Type", ctype)
	w.Header().Set("Cache-Control", "no-cache")
	_, _ = w.Write(b)
}
