package main

// 配置与持久化：端口转发规则、管理设置、密码盐值。
// 数据目录为飞牛 FPK 的 TRIM_PKGVAR，卸载应用不会误删卷内其它数据。

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode"
	"unicode/utf8"
)

// Forward 一条端口转发规则。
type Forward struct {
	ID         string    `json:"id"`
	Name       string    `json:"name"`
	Proto      string    `json:"proto"` // tcp | udp
	Listen     int       `json:"listen"`
	TargetHost string    `json:"targetHost"`
	TargetPort int       `json:"targetPort"`
	Enabled    bool      `json:"enabled"`
	Remark     string    `json:"remark"`
	CreatedAt  time.Time `json:"createdAt"`
}

// Config 应用的全部持久化配置。
type Config struct {
	PasswordHash  string    `json:"passwordHash"`
	Salt          string    `json:"salt"`
	Port          int       `json:"port"`
	IPv6          bool      `json:"ipv6"`
	AllowCIDR     []string  `json:"allowCidr"`
	ScanTimeoutMS int       `json:"scanTimeoutMs"`
	Forwards      []Forward `json:"forwards"`
}

// Store 线程安全的配置容器。
type Store struct {
	mu   sync.RWMutex
	path string
	cfg  Config
}

func NewStore(dataDir string) (*Store, error) {
	if err := os.MkdirAll(dataDir, 0o755); err != nil {
		return nil, err
	}
	s := &Store{path: filepath.Join(dataDir, "config.json")}
	if err := s.load(); err != nil {
		return nil, err
	}
	return s, nil
}

func (s *Store) load() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	b, err := os.ReadFile(s.path)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			return err
		}
		s.cfg = Config{Port: 8899, IPv6: true, ScanTimeoutMS: 300, Forwards: []Forward{}, AllowCIDR: []string{}}
		return s.persistLocked()
	}
	if err := json.Unmarshal(b, &s.cfg); err != nil {
		return fmt.Errorf("配置文件解析失败: %w", err)
	}
	// 旧配置没有 ipv6 键，按启用双栈处理，避免升级后 IPv6 访问静默失效。
	var raw map[string]json.RawMessage
	if json.Unmarshal(b, &raw) == nil {
		if _, ok := raw["ipv6"]; !ok {
			s.cfg.IPv6 = true
		}
	}
	if s.cfg.Port == 0 {
		s.cfg.Port = 8899
	}
	if s.cfg.ScanTimeoutMS <= 0 {
		s.cfg.ScanTimeoutMS = 300
	}
	if s.cfg.Forwards == nil {
		s.cfg.Forwards = []Forward{}
	}
	return nil
}

func (s *Store) persistLocked() error {
	b, err := json.MarshalIndent(s.cfg, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}

// Snapshot 返回配置副本，调用方可安全读取。
func (s *Store) Snapshot() Config {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := s.cfg
	out.Forwards = append([]Forward{}, s.cfg.Forwards...)
	out.AllowCIDR = append([]string{}, s.cfg.AllowCIDR...)
	return out
}

// Update 在写锁内修改配置并落盘。
func (s *Store) Update(fn func(cfg *Config) error) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := fn(&s.cfg); err != nil {
		return err
	}
	return s.persistLocked()
}

// SetPassword 使用 PBKDF2-SHA256 派生口令哈希，写入前校验口令强度。
func (s *Store) SetPassword(password string) error {
	if err := validatePassword(password); err != nil {
		return err
	}
	salt := randomHex(16)
	hash := pbkdf2Key(password, salt, 120000, 32)
	return s.Update(func(cfg *Config) error {
		cfg.Salt = salt
		cfg.PasswordHash = hash
		return nil
	})
}

// CheckPassword 常量时间比对口令。
func (s *Store) CheckPassword(password string) bool {
	cfg := s.Snapshot()
	if cfg.PasswordHash == "" || cfg.Salt == "" {
		return false
	}
	got := pbkdf2Key(password, cfg.Salt, 120000, 32)
	return subtle.ConstantTimeCompare([]byte(got), []byte(cfg.PasswordHash)) == 1
}

func (s *Store) Initialized() bool {
	cfg := s.Snapshot()
	return cfg.PasswordHash != "" && cfg.Salt != ""
}

// pbkdf2Key 标准库未导出 PBKDF2，这里按 RFC 2898 用 crypto/hmac 实现。
func pbkdf2Key(password, salt string, iter, keyLen int) string {
	prf := hmac.New(sha256.New, []byte(password))
	hLen := prf.Size()
	blocks := (keyLen + hLen - 1) / hLen
	out := make([]byte, 0, blocks*hLen)
	for i := 1; i <= blocks; i++ {
		prf.Reset()
		prf.Write([]byte(salt))
		prf.Write([]byte(strconv.Itoa(i)))
		u := prf.Sum(nil)
		t := make([]byte, len(u))
		copy(t, u)
		for j := 1; j < iter; j++ {
			prf.Reset()
			prf.Write(u)
			u = prf.Sum(nil)
			for k := 0; k < len(t); k++ {
				t[k] ^= u[k]
			}
		}
		out = append(out, t...)
	}
	return hex.EncodeToString(out[:keyLen])
}

func randomHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return fmt.Sprintf("%x", time.Now().UnixNano())
	}
	return hex.EncodeToString(b)
}

// 口令强度要求：至少 10 位，字母/数字/符号至少占两类，且不在常见弱口令表里。
const minPasswordLen = 10

var weakFragments = []string{
	"password", "passwd", "pwd123", "admin", "qwerty", "letmein", "iloveyou",
	"123456", "abcdef", "abc123", "root", "relaymgr", "fnos",
}

func validatePassword(pwd string) error {
	if utf8.RuneCountInString(pwd) < minPasswordLen {
		return fmt.Errorf("口令至少 %d 位", minPasswordLen)
	}
	var letter, digit, other bool
	for _, r := range pwd {
		switch {
		case unicode.IsLetter(r):
			letter = true
		case unicode.IsDigit(r):
			digit = true
		default:
			other = true
		}
	}
	kinds := 0
	for _, ok := range []bool{letter, digit, other} {
		if ok {
			kinds++
		}
	}
	if kinds < 2 {
		return errors.New("口令需包含字母、数字、符号中的至少两类")
	}
	lower := strings.ToLower(pwd)
	for _, frag := range weakFragments {
		if strings.Contains(lower, frag) {
			return fmt.Errorf("口令包含常见弱口令片段「%s」，请换一个", frag)
		}
	}
	// 拒绝靠重复字符凑长度的写法，例如 qqqqqqqq11、abababab12
	uniq := map[rune]struct{}{}
	for _, r := range lower {
		uniq[r] = struct{}{}
	}
	if len(uniq) <= 4 {
		return errors.New("口令字符种类太少，请换一个")
	}
	return nil
}
