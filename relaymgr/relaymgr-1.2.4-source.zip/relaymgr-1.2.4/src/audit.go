package main

// 审计日志：所有敏感操作（登录、改口令、增删规则、端口扫描）都会留痕。

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type AuditEntry struct {
	Time   time.Time `json:"time"`
	IP     string    `json:"ip"`
	Action string    `json:"action"`
	Detail string    `json:"detail"`
	Result string    `json:"result"`
}

type Audit struct {
	mu      sync.Mutex
	path    string
	entries []AuditEntry
}

func NewAudit(dataDir string) *Audit {
	a := &Audit{path: filepath.Join(dataDir, "audit.log")}
	a.load()
	return a
}

func (a *Audit) load() {
	f, err := os.Open(a.path)
	if err != nil {
		return
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 4096), 1<<20)
	for sc.Scan() {
		var e AuditEntry
		if json.Unmarshal(sc.Bytes(), &e) == nil {
			a.entries = append(a.entries, e)
		}
	}
	if len(a.entries) > 300 {
		a.entries = a.entries[len(a.entries)-300:]
	}
}

func (a *Audit) Append(ip, action, detail, result string) {
	e := AuditEntry{Time: time.Now(), IP: ip, Action: action, Detail: detail, Result: result}
	a.mu.Lock()
	defer a.mu.Unlock()
	a.entries = append(a.entries, e)
	if len(a.entries) > 300 {
		a.entries = a.entries[len(a.entries)-300:]
	}
	if f, err := os.OpenFile(a.path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600); err == nil {
		b, _ := json.Marshal(e)
		f.Write(append(b, '\n'))
		f.Close()
	}
}

func (a *Audit) Recent(limit int) []AuditEntry {
	a.mu.Lock()
	defer a.mu.Unlock()
	if limit <= 0 || limit > len(a.entries) {
		limit = len(a.entries)
	}
	start := len(a.entries) - limit
	out := make([]AuditEntry, limit)
	copy(out, a.entries[start:])
	// 新的在前
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}
