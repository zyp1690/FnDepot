package main

// 扫描增强：端口档位、Banner/服务指纹、风险标记、网关与本机识别。

import (
	"crypto/tls"
	"errors"
	"fmt"
	"net"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const maxCustomPorts = 200

// Service 是一个开放端口对应的服务指纹。
type Service struct {
	Port   int    `json:"port"`
	Name   string `json:"name"`
	Banner string `json:"banner,omitempty"`
}

// 扫描档位：端口越多越慢，快速档只探高价值端口。
var profilePorts = map[string][]int{
	"fast": {3389, 445, 22, 80, 5666, 9100, 5900, 5000},
	"standard": {
		3389, 445, 22, 80, 5666, 9100, 5900, 5000,
		443, 8080, 8081, 139, 5667, 8006, 32400, 5901,
		21, 23, 25, 53, 515, 631, 1433, 3306, 5432, 6379,
		8088, 8096, 8123, 8443, 8888, 9000, 9090, 11211, 5244, 548,
	},
	"deep": {
		3389, 445, 22, 80, 5666, 9100, 5900, 5000,
		443, 8080, 8081, 139, 5667, 8006, 32400, 5901,
		21, 23, 25, 53, 515, 631, 1433, 3306, 5432, 6379,
		8088, 8096, 8123, 8443, 8888, 9000, 9090, 11211, 5244, 548,
		110, 143, 993, 995, 1080, 1883, 2049, 2375, 2376, 3000,
		4443, 5060, 5061, 5672, 6080, 7001, 7002, 8000, 8008, 8009,
		8161, 9091, 9200, 9443, 10000, 27017, 25565, 19132, 37017, 61613,
	},
}

var serviceNames = map[int]string{
	20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
	80: "HTTP", 110: "POP3", 139: "NetBIOS", 143: "IMAP", 443: "HTTPS", 445: "SMB",
	515: "LPD 打印", 548: "AFP 文件共享", 631: "IPP 打印", 993: "IMAPS", 995: "POP3S",
	1080: "SOCKS", 1433: "SQL Server", 1883: "MQTT", 2049: "NFS", 2375: "Docker API",
	2376: "Docker TLS", 3000: "Web 应用", 3306: "MySQL", 3389: "RDP 远程桌面",
	4443: "HTTPS", 5000: "群晖 DSM", 5001: "群晖 DSM(HTTPS)", 5060: "SIP",
	5061: "SIP TLS", 5432: "PostgreSQL", 5666: "飞牛服务", 5667: "飞牛 HTTPS",
	5672: "AMQP", 5900: "VNC", 5901: "VNC", 6080: "noVNC", 6379: "Redis",
	7001: "WebLogic", 7002: "WebLogic SSL", 8000: "HTTP", 8006: "Proxmox VE",
	8008: "HTTP", 8009: "AJP", 8080: "HTTP", 8081: "HTTP", 8088: "HTTP",
	8096: "Jellyfin", 8123: "Home Assistant", 8161: "ActiveMQ", 8443: "HTTPS",
	8888: "HTTP", 9000: "Portainer", 9090: "HTTP", 9091: "HTTP", 9100: "打印 RAW",
	9200: "Elasticsearch", 9443: "HTTPS", 10000: "Webmin", 11211: "Memcached",
	25565: "Minecraft", 27017: "MongoDB", 32400: "Plex", 5244: "AList",
}

var httpPorts = map[int]bool{
	80: true, 443: true, 3000: true, 4443: true, 5000: true, 5001: true,
	5667: true, 7001: true, 7002: true, 8000: true, 8006: true, 8008: true,
	8080: true, 8081: true, 8088: true, 8096: true, 8123: true, 8161: true,
	8443: true, 8888: true, 9000: true, 9090: true, 9091: true, 9200: true,
	9443: true, 10000: true, 32400: true, 5244: true,
}

var tlsPorts = map[int]bool{
	443: true, 4443: true, 5001: true, 5667: true, 7002: true, 8006: true,
	8443: true, 9443: true, 2376: true,
}

var riskPorts = []struct {
	port int
	text string
}{
	{23, "Telnet 明文口令"},
	{21, "FTP 明文传输"},
	{445, "SMB 暴露，谨防勒索横移"},
	{3389, "RDP 直连暴露，建议只走本应用转发"},
	{5900, "VNC 多为无加密"},
	{5901, "VNC 多为无加密"},
	{3306, "MySQL 端口对外"},
	{5432, "PostgreSQL 端口对外"},
	{6379, "Redis 未授权访问高发"},
	{11211, "Memcached 反射放大风险"},
	{27017, "MongoDB 未授权访问高发"},
	{2375, "Docker API 无 TLS 暴露"},
	{9100, "打印机裸端口"},
	{9200, "Elasticsearch 未授权高发"},
}

// resolvePorts 把档位或自定义端口串解析成端口列表。
func resolvePorts(profile, custom string) ([]int, error) {
	profile = strings.TrimSpace(strings.ToLower(profile))
	if profile == "" {
		profile = "standard"
	}
	if profile == "full" {
		out := make([]int, 65535)
		for i := range out {
			out[i] = i + 1
		}
		return out, nil
	}
	if profile == "custom" {
		list, err := parsePortList(custom)
		if err != nil {
			return nil, err
		}
		if len(list) == 0 {
			return nil, errors.New("自定义端口为空，例如 3389,8080 或 8000-8100")
		}
		return list, nil
	}
	list, ok := profilePorts[profile]
	if !ok {
		return nil, errors.New("扫描档位只能是 fast / standard / deep / custom")
	}
	out := append([]int{}, list...)
	sort.Ints(out)
	return out, nil
}

// parsePortList 支持逗号分隔的单个端口与 a-b 区间，最多 200 个端口。
func parsePortList(s string) ([]int, error) {
	seen := map[int]bool{}
	out := []int{}
	for _, part := range strings.FieldsFunc(s, func(r rune) bool {
		return r == ',' || r == ' ' || r == ';' || r == '\n' || r == '\t'
	}) {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if strings.Contains(part, "-") {
			segs := strings.SplitN(part, "-", 2)
			lo, err1 := strconv.Atoi(strings.TrimSpace(segs[0]))
			hi, err2 := strconv.Atoi(strings.TrimSpace(segs[1]))
			if err1 != nil || err2 != nil || lo < 1 || hi > 65535 || lo > hi {
				return nil, fmt.Errorf("端口区间格式不正确: %s", part)
			}
			for p := lo; p <= hi; p++ {
				if len(out) >= maxCustomPorts {
					return nil, fmt.Errorf("自定义端口最多 %d 个，当前区间 %s 已超出，请缩小范围或改用「全端口」档", maxCustomPorts, part)
				}
				if !seen[p] {
					seen[p] = true
					out = append(out, p)
				}
			}
		} else {
			p, err := strconv.Atoi(part)
			if err != nil || p < 1 || p > 65535 {
				return nil, fmt.Errorf("端口格式不正确: %s", part)
			}
			if !seen[p] && len(out) >= maxCustomPorts {
				return nil, fmt.Errorf("自定义端口最多 %d 个，请缩小范围或改用「全端口」档", maxCustomPorts)
			}
			if !seen[p] {
				seen[p] = true
				out = append(out, p)
			}
		}
	}
	sort.Ints(out)
	return out, nil
}

// scanFirstWave 取存活探测用的最多 8 个端口：优先常用端口，
// 自定义冷门端口（如 9097）也一定进入首轮，否则整段扫不出存活。
func scanFirstWave(ports []int) []int {
	if len(ports) <= 8 {
		return append([]int{}, ports...)
	}
	prefer := []int{3389, 445, 22, 80, 5666, 9100, 5900, 5000}
	set := map[int]bool{}
	for _, p := range ports {
		set[p] = true
	}
	out := []int{}
	used := map[int]bool{}
	for _, p := range prefer {
		if set[p] && !used[p] {
			out = append(out, p)
			used[p] = true
		}
	}
	rest := []int{}
	for _, p := range ports {
		if !used[p] {
			rest = append(rest, p)
		}
	}
	need := 8 - len(out)
	if need <= 0 || len(rest) == 0 {
		return out
	}
	if need >= len(rest) {
		return append(out, rest...)
	}
	// 在剩余端口里均匀取样（含首尾），避免只探前几个端口导致整段漏判存活。
	for i := 0; i < need; i++ {
		idx := len(rest) / 2
		if need > 1 {
			idx = i * (len(rest) - 1) / (need - 1)
		}
		p := rest[idx]
		if used[p] {
			continue
		}
		used[p] = true
		out = append(out, p)
	}
	return out
}

// fullSamplePorts 取一组均匀分布的端口，用于判断目标对探测的响应模式。
func fullSamplePorts() []int {
	out := []int{22, 80, 443, 445, 3389, 5900, 6668, 8080, 8081, 8443, 9090, 9100, 10000, 8088, 8123, 8096, 9000, 32400, 5000, 5666}
	for i := 1; i <= 12; i++ {
		out = append(out, i*65535/13)
	}
	return out
}

// probeSample 对样本端口探测一次：返回开放端口数与超时数。
// 超时说明目标不回包（设备限流/防火墙），这时必须降低并发，否则会把弱设备的
// 连接槽打满，反而漏掉真正开放的端口。
func probeSample(ip string, ports []int, timeout time.Duration) ([]int, int) {
	open := []int{}
	timeouts := 0
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, 32)
	for _, p := range ports {
		wg.Add(1)
		sem <- struct{}{}
		go func(port int) {
			defer func() { <-sem; wg.Done() }()
			conn, err := net.DialTimeout("tcp", net.JoinHostPort(ip, strconv.Itoa(port)), timeout)
			if err == nil {
				conn.Close()
				mu.Lock()
				open = append(open, port)
				mu.Unlock()
				return
			}
			var nerr net.Error
			if errors.As(err, &nerr) && nerr.Timeout() {
				mu.Lock()
				timeouts++
				mu.Unlock()
			}
		}(p)
	}
	wg.Wait()
	sort.Ints(open)
	return open, timeouts
}

func portsExcept(all, first []int) []int {
	skip := map[int]bool{}
	for _, p := range first {
		skip[p] = true
	}
	out := []int{}
	for _, p := range all {
		if !skip[p] {
			out = append(out, p)
		}
	}
	return out
}

// fingerprint 对一个端口做轻量探测，返回服务名与横幅。
// 未知端口先等 banner，没有响应再补一次 HTTP 试探（网页服务不会主动发 banner）。
func fingerprint(ip string, port int, timeout time.Duration) Service {
	svc := Service{Port: port, Name: serviceName(port)}
	addr := net.JoinHostPort(ip, strconv.Itoa(port))
	banner := ""
	if httpPorts[port] {
		banner = httpProbe(addr, tlsPorts[port], timeout)
	} else {
		banner = readBanner(addr, timeout)
		if banner == "" {
			banner = httpProbe(addr, tlsPorts[port], timeout)
			if banner != "" {
				svc.Name = "HTTP"
			}
		}
	}
	if banner != "" {
		svc.Banner = banner
		svc.Name = refineName(svc.Name, banner)
	}
	return svc
}

// refineName 用横幅再细分服务名（NAS 面板、媒体服务器、软路由等）。
func refineName(name, banner string) string {
	low := strings.ToLower(banner)
	switch {
	case strings.Contains(low, "jellyfin"):
		return "Jellyfin"
	case strings.Contains(low, "plex"):
		return "Plex"
	case strings.Contains(low, "home assistant"), strings.Contains(low, "homeassistant"):
		return "Home Assistant"
	case strings.Contains(low, "portainer"):
		return "Portainer"
	case strings.Contains(low, "proxmox"):
		return "Proxmox VE"
	case strings.Contains(low, "synology"), strings.Contains(low, "dsm"):
		return "群晖 DSM"
	case strings.Contains(low, "openwrt"), strings.Contains(low, "luci"):
		return "OpenWrt"
	case strings.Contains(low, "fnos"), strings.Contains(low, "feiniu"):
		return "飞牛 fnOS"
	case strings.Contains(low, "openssh"):
		return "SSH"
	}
	return name
}

// fingerprints 并发给一台主机的开放端口做指纹，最多取前 12 个端口。
func fingerprints(ip string, ports []int, timeout time.Duration, limit int) []Service {
	if limit <= 0 {
		limit = 12
	}
	if len(ports) > limit {
		ports = ports[:limit]
	}
	out := make([]Service, 0, len(ports))
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, 6)
	for _, p := range ports {
		wg.Add(1)
		sem <- struct{}{}
		go func(port int) {
			defer func() { <-sem; wg.Done() }()
			svc := fingerprint(ip, port, timeout)
			mu.Lock()
			out = append(out, svc)
			mu.Unlock()
		}(p)
	}
	wg.Wait()
	sort.Slice(out, func(i, j int) bool { return out[i].Port < out[j].Port })
	return out
}

func serviceName(port int) string {
	if name, ok := serviceNames[port]; ok {
		return name
	}
	return "TCP " + strconv.Itoa(port)
}

// httpProbe 只取响应头里的 Server 标识，不下载页面正文。
func httpProbe(addr string, useTLS bool, timeout time.Duration) string {
	d := &net.Dialer{Timeout: timeout}
	var conn net.Conn
	var err error
	if useTLS {
		conn, err = tls.DialWithDialer(d, "tcp", addr, &tls.Config{InsecureSkipVerify: true})
	} else {
		conn, err = d.Dial("tcp", addr)
	}
	if err != nil {
		return ""
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(1500 * time.Millisecond))
	_, _ = fmt.Fprintf(conn, "HEAD / HTTP/1.0\r\nHost: %s\r\nUser-Agent: relaymgr-scan\r\nConnection: close\r\n\r\n", addr)
	buf := make([]byte, 1024)
	n, _ := conn.Read(buf)
	if n == 0 {
		return ""
	}
	head := string(buf[:n])
	server := ""
	for _, line := range strings.Split(head, "\n") {
		line = strings.TrimSpace(line)
		if len(line) > 8 && strings.EqualFold(line[:7], "Server:") {
			server = strings.TrimSpace(line[7:])
			break
		}
	}
	if server == "" {
		// 没有 Server 头时至少带上状态行，便于人工判断是不是 HTTP 服务。
		if strings.HasPrefix(head, "HTTP/") {
			server = strings.TrimSpace(strings.Split(head, "\r")[0])
		}
	}
	return cleanBanner(server)
}

func readBanner(addr string, timeout time.Duration) string {
	d := &net.Dialer{Timeout: timeout}
	conn, err := d.Dial("tcp", addr)
	if err != nil {
		return ""
	}
	defer conn.Close()
	_ = conn.SetReadDeadline(time.Now().Add(timeout))
	buf := make([]byte, 512)
	n, err := conn.Read(buf)
	if n == 0 {
		return ""
	}
	if err != nil && n < 4 {
		return ""
	}
	return cleanBanner(string(buf[:n]))
}

// cleanBanner 去掉控制字符并截断，避免把原始字节直接塞进界面。
func cleanBanner(s string) string {
	s = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return ' '
		}
		return r
	}, s)
	s = strings.Join(strings.Fields(s), " ")
	if len([]rune(s)) > 90 {
		s = string([]rune(s)[:90]) + "…"
	}
	return s
}

func risksFor(ports []int) []string {
	out := []string{}
	for _, r := range riskPorts {
		if r.text == "" {
			continue
		}
		for _, p := range ports {
			if p == r.port {
				out = append(out, r.text)
				break
			}
		}
	}
	return out
}

// guessKindEnhanced 在端口规则之外，用服务指纹再细分设备类型。
func guessKindEnhanced(ports []int, services []Service, mac string) string {
	for _, s := range services {
		n := strings.ToLower(s.Name)
		switch {
		case strings.Contains(n, "fnos") || strings.Contains(n, "飞牛"):
			return "飞牛 NAS"
		case strings.Contains(n, "jellyfin"), strings.Contains(n, "plex"):
			return "媒体服务器"
		case strings.Contains(n, "home assistant"):
			return "智能家居主机"
		case strings.Contains(n, "proxmox"):
			return "虚拟化主机"
		case strings.Contains(n, "portainer"):
			return "Docker 主机"
		case strings.Contains(n, "synology"), strings.Contains(n, "群晖"):
			return "群晖 NAS"
		case strings.Contains(n, "openwrt"):
			return "路由器"
		}
	}
	return guessKind(ports, mac)
}

// flagsFor 标记本机 / 网关 / 新上线设备。
func flagsFor(ip string, self map[string]bool, gateway string, prev map[string]Host, prevCIDR, cidr string) []string {
	out := []string{}
	if self[ip] {
		out = append(out, "self")
	}
	if gateway != "" && ip == gateway {
		out = append(out, "gateway")
	}
	if len(prev) > 0 && prevCIDR == cidr {
		if _, ok := prev[ip]; !ok {
			out = append(out, "new")
		}
	}
	return out
}

// localIPv4Set 取本机所有 IPv4 地址，用于标记“本机”。
func localIPv4Set() map[string]bool {
	out := map[string]bool{"127.0.0.1": true}
	v4, _ := localAddrs()
	for _, s := range v4 {
		out[s] = true
	}
	return out
}

// defaultGateway 从 /proc/net/route 读取默认网关。
func defaultGateway() string {
	b, err := os.ReadFile("/proc/net/route")
	if err != nil {
		return ""
	}
	for i, line := range strings.Split(string(b), "\n") {
		if i == 0 {
			continue
		}
		f := strings.Fields(line)
		if len(f) < 4 {
			continue
		}
		if f[1] != "00000000" {
			continue
		}
		// Flags 必须包含 RTF_GATEWAY(0x2)
		v, err := strconv.ParseInt(f[3], 16, 32)
		if err != nil || v&0x2 == 0 {
			continue
		}
		gw, err := strconv.ParseUint(f[2], 16, 32)
		if err != nil {
			continue
		}
		ip := net.IPv4(byte(gw&0xff), byte((gw>>8)&0xff), byte((gw>>16)&0xff), byte((gw>>24)&0xff))
		return ip.String()
	}
	return ""
}
