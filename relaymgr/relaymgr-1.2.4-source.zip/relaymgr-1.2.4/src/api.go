package main

// HTTP API：认证、转发规则、内网扫描、设置与审计。

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

const cookieName = "relaymgr_session"

type Server struct {
	web     fs.FS
	store   *Store
	auth    *Auth
	fwd     *ForwardManager
	disc    *Discovery
	audit   *Audit
	started time.Time
	version string

	// 由 main 注入：查询/切换管理界面的监听端口与协议栈。
	listenInfo func() (int, bool, string)
	restart    func(port int, ipv6 bool) (string, error)
}

func NewServer(store *Store, auth *Auth, fwd *ForwardManager, disc *Discovery, audit *Audit) *Server {
	return &Server{store: store, auth: auth, fwd: fwd, disc: disc, audit: audit, started: time.Now(), version: AppVersion}
}

// ---- 通用响应 ----

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]any{"ok": false, "error": msg})
}

func writeOK(w http.ResponseWriter, v any) {
	if v == nil {
		v = map[string]any{"ok": true}
	}
	if m, ok := v.(map[string]any); ok {
		m["ok"] = true
		v = m
	}
	writeJSON(w, 200, v)
}

func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	// 只有当对端是本机/内网（典型是 nginx、Lucky、Docker 里的反代）时才信任代理头，
	// 直连公网时客户端自己伪造 X-Forwarded-For 不会生效。
	if ip := net.ParseIP(host); ip != nil && (ip.IsLoopback() || ip.IsPrivate()) {
		if v := forwardedIP(r); v != "" {
			return v
		}
	}
	return host
}

// forwardedIP 取代理声明的第一跳真实来源；非法值一律忽略。
func forwardedIP(r *http.Request) string {
	raw := strings.TrimSpace(r.Header.Get("X-Forwarded-For"))
	if raw == "" {
		raw = strings.TrimSpace(r.Header.Get("X-Real-IP"))
	}
	if raw == "" {
		return ""
	}
	first := strings.TrimSpace(strings.Split(raw, ",")[0])
	if net.ParseIP(first) == nil {
		return ""
	}
	return first
}

// isLANRequest 判定来源是否为局域网。
// 直连时只看真实对端地址，公网来源伪造 X-Forwarded-For 不会生效；
// 本机来源（多为 nginx 等反向代理）再结合代理声明的真实来源判断，避免
// 公网经反代打进来时被误判成内网。
func isLANRequest(r *http.Request) bool {
	return isPrivateIP(net.ParseIP(clientIP(r)))
}

func (s *Server) session(r *http.Request) (string, bool) {
	c, err := r.Cookie(cookieName)
	if err != nil {
		return "", false
	}
	if !s.auth.Valid(c.Value) {
		return "", false
	}
	return c.Value, true
}

// ---- 准入控制 ----

func (s *Server) guard(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cfg := s.store.Snapshot()
		if len(cfg.AllowCIDR) > 0 {
			ip := net.ParseIP(clientIP(r))
			allowed := false
			for _, c := range cfg.AllowCIDR {
				if c == "" {
					continue
				}
				if strings.Contains(c, "/") {
					if _, n, err := net.ParseCIDR(c); err == nil && n.Contains(ip) {
						allowed = true
					}
				} else if net.ParseIP(c) != nil && net.ParseIP(c).Equal(ip) {
					allowed = true
				}
			}
			if !allowed {
				s.audit.Append(clientIP(r), "access", "来源不在 IP 白名单内: "+clientIP(r), "拒绝")
				writeErr(w, http.StatusForbidden, "当前来源 IP 不在白名单内")
				return
			}
		}
		// 基础安全响应头；应用走 HTTP，iframe 内嵌不做 X-Frame-Options 限制。
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		next.ServeHTTP(w, r)
	})
}

func (s *Server) requireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if _, ok := s.session(r); !ok {
			writeErr(w, http.StatusUnauthorized, "未登录或会话已过期")
			return
		}
		next(w, r)
	}
}

// ---- 路由 ----

func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/state", s.handleState)
	mux.HandleFunc("/api/setup", s.handleSetup)
	mux.HandleFunc("/api/login", s.handleLogin)
	mux.HandleFunc("/api/logout", s.requireAuth(s.handleLogout))
	mux.HandleFunc("/api/system", s.requireAuth(s.handleSystem))
	mux.HandleFunc("/api/forwards", s.requireAuth(s.handleForwards))
	mux.HandleFunc("/api/forwards/toggle", s.requireAuth(s.handleToggle))
	mux.HandleFunc("/api/scan", s.requireAuth(s.handleScanStart))
	mux.HandleFunc("/api/scan/status", s.requireAuth(s.handleScanStatus))
	mux.HandleFunc("/api/scan/stop", s.requireAuth(s.handleScanStop))
	mux.HandleFunc("/api/hosts", s.requireAuth(s.handleHosts))
	mux.HandleFunc("/api/localports", s.requireAuth(s.handleLocalPorts))
	mux.HandleFunc("/api/settings", s.requireAuth(s.handleSettings))
	mux.HandleFunc("/api/password", s.requireAuth(s.handlePassword))
	mux.HandleFunc("/api/audit", s.requireAuth(s.handleAudit))
	mux.HandleFunc("/", s.handleStatic)
	return s.guard(mux)
}

// ---- 状态 / 登录 ----

func (s *Server) handleState(w http.ResponseWriter, r *http.Request) {
	initialized := s.auth.Initialized()
	_, authed := s.session(r)

	resp := map[string]any{
		"initialized":   initialized,
		"authed":        authed,
		"lan":           isLANRequest(r),
		"lockRemainSec": s.auth.LockRemain(clientIP(r)),
		"version":       s.version,
	}
	if !authed {
		writeJSON(w, 200, resp)
		return
	}

	cfg := s.store.Snapshot()
	resp["port"] = cfg.Port
	resp["ipv6"] = cfg.IPv6
	if s.listenInfo != nil {
		lp, lv6, mode := s.listenInfo()
		resp["listenPort"] = lp
		resp["listenMode"] = mode
		resp["ipv6Active"] = lv6
	}
	v4addrs, v6addrs := localAddrs()
	resp["addrs4"] = v4addrs
	resp["addrs6"] = v6addrs
	resp["allowCidr"] = cfg.AllowCIDR
	resp["scanTimeoutMs"] = cfg.ScanTimeoutMS
	resp["uptimeSec"] = int(time.Since(s.started).Seconds())
	resp["scan"] = s.disc.Status()
	resp["hostCount"] = len(s.disc.Hosts())
	resp["forwards"] = s.forwardsWithStats(cfg.Forwards)
	resp["interfaces"] = s.disc.Interfaces()
	resp["hostname"], _ = os.Hostname()
	resp["portForwardMode"] = "direct"
	writeJSON(w, 200, resp)
}

func (s *Server) forwardsWithStats(list []Forward) []map[string]any {
	stats := s.fwd.Stats()
	out := make([]map[string]any, 0, len(list))
	for _, f := range list {
		m := map[string]any{
			"id": f.ID, "name": f.Name, "proto": f.Proto, "listen": f.Listen,
			"targetHost": f.TargetHost, "targetPort": f.TargetPort,
			"enabled": f.Enabled, "remark": f.Remark, "createdAt": f.CreatedAt,
			// 未运行的规则也要给齐统计字段，前端按同一结构渲染
			"running": false, "lastError": "", "active": 0,
			"bytesIn": 0, "bytesOut": 0, "total": 0, "lastActive": 0,
		}
		if st, ok := stats[f.ID]; ok {
			for k, v := range st {
				m[k] = v
			}
		}
		out = append(out, m)
	}
	return out
}

func (s *Server) handleSetup(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	ip := clientIP(r)
	if err := s.auth.Setup(req.Password, ip); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	token, err := s.auth.Login(req.Password, ip)
	if err != nil {
		writeOK(w, map[string]any{"initialized": true, "needLogin": true})
		return
	}
	s.setCookie(w, token)
	writeOK(w, map[string]any{"initialized": true, "authed": true})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	token, err := s.auth.Login(req.Password, clientIP(r))
	if err != nil {
		code := http.StatusUnauthorized
		if errors.Is(err, ErrRateLimited) || errors.Is(err, ErrLocked) {
			code = http.StatusTooManyRequests
		}
		writeErr(w, code, err.Error())
		return
	}
	s.setCookie(w, token)
	writeOK(w, nil)
}

func (s *Server) setCookie(w http.ResponseWriter, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     cookieName,
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   int(sessionTTL.Seconds()),
	})
}

func (s *Server) handleLogout(w http.ResponseWriter, r *http.Request) {
	token, _ := s.session(r)
	s.auth.Logout(token)
	http.SetCookie(w, &http.Cookie{Name: cookieName, Value: "", Path: "/", MaxAge: -1, HttpOnly: true})
	writeOK(w, nil)
}

func (s *Server) handleSystem(w http.ResponseWriter, r *http.Request) {
	host, _ := os.Hostname()
	writeOK(w, map[string]any{"hostname": host, "version": s.version, "uptimeSec": int(time.Since(s.started).Seconds()), "interfaces": s.disc.Interfaces()})
}

// ---- 转发规则 ----

func (s *Server) handleForwards(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		writeOK(w, map[string]any{"forwards": s.forwardsWithStats(s.store.Snapshot().Forwards)})
	case http.MethodPost:
		s.saveForward(w, r)
	case http.MethodDelete:
		id := r.URL.Query().Get("id")
		if id == "" {
			writeErr(w, 400, "缺少规则 id")
			return
		}
		if err := s.fwd.Delete(id); err != nil {
			writeErr(w, 500, err.Error())
			return
		}
		s.audit.Append(clientIP(r), "forward", "删除转发规则 "+id, "成功")
		writeOK(w, nil)
	default:
		writeErr(w, 405, "方法不支持")
	}
}

func (s *Server) saveForward(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ID         string `json:"id"`
		Name       string `json:"name"`
		Proto      string `json:"proto"`
		Listen     int    `json:"listen"`
		TargetHost string `json:"targetHost"`
		TargetPort int    `json:"targetPort"`
		Enabled    bool   `json:"enabled"`
		Remark     string `json:"remark"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	req.Name = strings.TrimSpace(req.Name)
	req.TargetHost = strings.TrimSpace(req.TargetHost)
	req.Proto = strings.ToLower(strings.TrimSpace(req.Proto))
	if req.Proto == "" {
		req.Proto = "tcp"
	}
	if req.Proto != "tcp" && req.Proto != "udp" {
		writeErr(w, 400, "协议只能是 tcp 或 udp")
		return
	}
	if req.Listen < 1 || req.Listen > 65535 {
		writeErr(w, 400, "监听端口需在 1-65535 之间")
		return
	}
	if req.Listen < 1024 {
		writeErr(w, 400, "1024 以下为系统保留端口，应用以普通用户运行无法监听，请改用 1024-65535")
		return
	}
	if req.TargetPort < 1 || req.TargetPort > 65535 {
		writeErr(w, 400, "目标端口需在 1-65535 之间")
		return
	}
	if req.TargetHost == "" {
		writeErr(w, 400, "请填写目标主机 IP 或域名")
		return
	}
	if req.Name == "" {
		req.Name = fmt.Sprintf("%s %d", strings.ToUpper(req.Proto), req.Listen)
	}

	cfg := s.store.Snapshot()
	if req.Listen == cfg.Port {
		writeErr(w, 400, "监听端口与管理端口冲突，请换一个端口")
		return
	}
	// 同协议下监听端口必须唯一（不同协议可共用端口）。
	for _, f := range cfg.Forwards {
		if f.ID != req.ID && f.Listen == req.Listen && f.Proto == req.Proto {
			writeErr(w, 400, fmt.Sprintf("端口 %d 已被规则「%s」占用", req.Listen, f.Name))
			return
		}
	}
	// 目标地址格式校验：IP（含 IPv6 带 %zone）或合法主机名。
	if !isIPLiteral(req.TargetHost) {
		if strings.ContainsAny(req.TargetHost, " :/") || len(req.TargetHost) > 253 {
			writeErr(w, 400, "目标地址格式不正确")
			return
		}
	}

	if req.ID == "" {
		req.ID = randomHex(6)
	}
	rule := Forward{
		ID: req.ID, Name: req.Name, Proto: req.Proto, Listen: req.Listen,
		TargetHost: req.TargetHost, TargetPort: req.TargetPort,
		Enabled: req.Enabled, Remark: req.Remark, CreatedAt: time.Now(),
	}
	if err := s.fwd.Upsert(rule); err != nil {
		s.audit.Append(clientIP(r), "forward", "保存规则失败 "+req.Name, "失败")
		writeErr(w, 500, err.Error())
		return
	}
	s.audit.Append(clientIP(r), "forward", fmt.Sprintf("保存规则 %s %s %d -> %s:%d", req.Name, strings.ToUpper(req.Proto), req.Listen, req.TargetHost, req.TargetPort), "成功")
	writeOK(w, map[string]any{"forwards": s.forwardsWithStats(s.store.Snapshot().Forwards)})
}

func (s *Server) handleToggle(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	var req struct {
		ID      string `json:"id"`
		Enabled bool   `json:"enabled"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if err := s.fwd.SetEnabled(req.ID, req.Enabled); err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	state := "停用"
	if req.Enabled {
		state = "启用"
	}
	s.audit.Append(clientIP(r), "forward", state+"转发规则 "+req.ID, "成功")
	writeOK(w, map[string]any{"forwards": s.forwardsWithStats(s.store.Snapshot().Forwards)})
}

// ---- 内网发现 ----

func (s *Server) handleScanStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	var req struct {
		CIDR      string `json:"cidr"`
		Profile   string `json:"profile"`
		Ports     string `json:"ports"`
		Conc      int    `json:"conc"`
		Speed     string `json:"speed"`
		UsePing   bool   `json:"usePing"`
		ForcePort bool   `json:"forcePort"`
		CheckSMB  bool   `json:"checkSMB"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	s.disc.SetTimeout(s.store.Snapshot().ScanTimeoutMS)
	opts := ScanOptions{Speed: req.Speed, UsePing: req.UsePing, ForcePort: req.ForcePort, CheckSMB: req.CheckSMB}
	if err := s.disc.Start(req.CIDR, req.Profile, req.Ports, req.Conc, opts); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	s.audit.Append(clientIP(r), "scan", "扫描网段 "+req.CIDR, "开始")
	writeOK(w, map[string]any{"status": s.disc.Status()})
}

func (s *Server) handleScanStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	s.disc.Stop()
	s.audit.Append(clientIP(r), "scan", "手动停止扫描", "成功")
	writeJSON(w, 200, map[string]any{"ok": true, "status": s.disc.Status()})
}

func (s *Server) handleScanStatus(w http.ResponseWriter, r *http.Request) {
	writeOK(w, map[string]any{"status": s.disc.Status()})
}

func (s *Server) handleHosts(w http.ResponseWriter, r *http.Request) {
	hosts := s.disc.Hosts()
	sort.Slice(hosts, func(i, j int) bool { return ipLess(hosts[i].IP, hosts[j].IP) })
	writeOK(w, map[string]any{"hosts": hosts, "interfaces": s.disc.Interfaces()})
}

func (s *Server) handleLocalPorts(w http.ResponseWriter, r *http.Request) {
	writeOK(w, collectLocalPorts())
}

// ---- 设置 ----

func (s *Server) handleSettings(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		cfg := s.store.Snapshot()
		resp := map[string]any{
			"port": cfg.Port, "ipv6": cfg.IPv6,
			"allowCidr": cfg.AllowCIDR, "scanTimeoutMs": cfg.ScanTimeoutMS,
		}
		if s.listenInfo != nil {
			lp, _, mode := s.listenInfo()
			resp["listenPort"] = lp
			resp["listenMode"] = mode
		}
		v4, v6addrs := localAddrs()
		resp["addrs4"], resp["addrs6"] = v4, v6addrs
		writeOK(w, resp)
		return
	}
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	var req struct {
		Port          *int     `json:"port"`
		IPv6          *bool    `json:"ipv6"`
		AllowCIDR     []string `json:"allowCidr"`
		ScanTimeoutMS *int     `json:"scanTimeoutMs"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	for _, c := range req.AllowCIDR {
		c = strings.TrimSpace(c)
		if c == "" {
			continue
		}
		if strings.Contains(c, "/") {
			if _, _, err := net.ParseCIDR(c); err != nil {
				writeErr(w, 400, "白名单网段格式不正确: "+c)
				return
			}
		} else if net.ParseIP(c) == nil {
			writeErr(w, 400, "白名单 IP 格式不正确: "+c)
			return
		}
	}

	cur := s.store.Snapshot()
	newPort, newIPv6 := cur.Port, cur.IPv6
	if req.Port != nil {
		newPort = *req.Port
	}
	if req.IPv6 != nil {
		newIPv6 = *req.IPv6
	}
	if newPort < 1 || newPort > 65535 {
		writeErr(w, 400, "管理端口需在 1-65535 之间")
		return
	}
	for _, f := range cur.Forwards {
		if f.Enabled && f.Proto == "tcp" && f.Listen == newPort {
			writeErr(w, 400, fmt.Sprintf("端口 %d 已被转发规则「%s」占用，请先改该规则", newPort, f.Name))
			return
		}
	}

	// 端口或协议栈变化时先切监听，绑定失败就不落盘，避免配置与实际不一致。
	rebind := newPort != cur.Port || newIPv6 != cur.IPv6
	mode := ""
	if rebind && s.restart != nil {
		m, err := s.restart(newPort, newIPv6)
		if err != nil {
			writeErr(w, 400, fmt.Sprintf("端口 %d 监听失败：%v", newPort, err))
			return
		}
		mode = m
	}

	portChanged := newPort != cur.Port
	if err := s.store.Update(func(cfg *Config) error {
		cfg.Port = newPort
		cfg.IPv6 = newIPv6
		if req.AllowCIDR != nil {
			clean := []string{}
			for _, c := range req.AllowCIDR {
				if strings.TrimSpace(c) != "" {
					clean = append(clean, strings.TrimSpace(c))
				}
			}
			cfg.AllowCIDR = clean
		}
		if req.ScanTimeoutMS != nil {
			v := *req.ScanTimeoutMS
			if v < 50 {
				v = 50
			}
			if v > 3000 {
				v = 3000
			}
			cfg.ScanTimeoutMS = v
			s.disc.SetTimeout(v)
		}
		return nil
	}); err != nil {
		// 配置没落盘就说明这次改动没生效，把监听切回原端口，避免
		// “接口报失败、实际已经换端口、重启又回退”的不一致。
		if rebind && s.restart != nil {
			if _, rerr := s.restart(cur.Port, cur.IPv6); rerr != nil {
				log.Printf("[relaymgr] 回滚监听到 %d 失败: %v", cur.Port, rerr)
			}
		}
		writeErr(w, 400, err.Error())
		return
	}

	stack := modeV4
	if newIPv6 {
		stack = modeDual
	}
	s.audit.Append(clientIP(r), "settings", fmt.Sprintf("更新管理设置（端口 %d，协议栈 %s）", newPort, stack), "成功")

	resp := map[string]any{"ok": true, "port": newPort, "ipv6": newIPv6}
	if rebind {
		resp["listenMode"] = mode
	}
	if portChanged {
		resp["notice"] = fmt.Sprintf("管理界面已在 %d 端口重新监听，飞牛桌面入口已同步", newPort)
	}
	// 新白名单不包含当前来源时提示一下，避免保存后立刻把自己拦在门外。
	if req.AllowCIDR != nil && len(req.AllowCIDR) > 0 {
		if ip := clientIP(r); !cidrListContains(s.store.Snapshot().AllowCIDR, ip) {
			resp["warning"] = fmt.Sprintf("当前来源 %s 不在白名单内，保存后这个地址将无法再访问，请确认", ip)
		}
	}
	writeJSON(w, 200, resp)
}

func (s *Server) handlePassword(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "方法不支持")
		return
	}
	var req struct {
		Old string `json:"old"`
		New string `json:"new"`
	}
	if err := decodeBody(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	token, _ := s.session(r)
	if err := s.auth.ChangePassword(req.Old, req.New, clientIP(r), token); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeOK(w, nil)
}

func (s *Server) handleAudit(w http.ResponseWriter, r *http.Request) {
	limit := 80
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 300 {
			limit = n
		}
	}
	writeOK(w, map[string]any{"entries": s.audit.Recent(limit)})
}

func decodeBody(r *http.Request, v any) error {
	if r.Body == nil {
		return errors.New("请求体为空")
	}
	r.Body = http.MaxBytesReader(nil, r.Body, 1<<20)
	dec := json.NewDecoder(r.Body)
	if err := dec.Decode(v); err != nil {
		if errors.Is(err, io.EOF) {
			return errors.New("请求体为空")
		}
		return errors.New("请求参数格式不正确")
	}
	return nil
}

// isIPLiteral 判断是否为 IP 字面量，允许 IPv6 链路本地地址的 %zone 后缀。
// cidrListContains 判断某个 IP 是否命中白名单（支持单 IP 与 CIDR）。
func cidrListContains(list []string, ipStr string) bool {
	ip := net.ParseIP(ipStr)
	if ip == nil {
		return false
	}
	for _, c := range list {
		c = strings.TrimSpace(c)
		if c == "" {
			continue
		}
		if strings.Contains(c, "/") {
			if _, n, err := net.ParseCIDR(c); err == nil && n.Contains(ip) {
				return true
			}
		} else if v := net.ParseIP(c); v != nil && v.Equal(ip) {
			return true
		}
	}
	return false
}

func isIPLiteral(host string) bool {
	if net.ParseIP(host) != nil {
		return true
	}
	if i := strings.Index(host, "%"); i > 0 {
		return net.ParseIP(host[:i]) != nil
	}
	return false
}
