package main

// 扫描选项相关能力：ICMP 探活、SMB 服务探测、速度映射。

import (
	"encoding/binary"
	"encoding/hex"
	"net"
	"strconv"
	"strings"
	"time"
)

// icmpPing 用 ICMP Echo 判断主机是否在线。需要 root/CAP_NET_RAW；
// 权限不足时返回 false，调用方会退回到 TCP 探活。
func icmpPing(ip string, timeout time.Duration) bool {
	conn, err := net.DialTimeout("ip4:icmp", ip, timeout)
	if err != nil {
		return false
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(timeout))

	buf := make([]byte, 8)
	buf[0] = 8 // Echo Request
	buf[1] = 0
	binary.BigEndian.PutUint16(buf[4:6], 1)
	binary.BigEndian.PutUint16(buf[6:8], 1)
	binary.BigEndian.PutUint16(buf[2:4], icmpChecksum(buf))
	if _, err := conn.Write(buf); err != nil {
		return false
	}
	reply := make([]byte, 1500)
	for {
		n, err := conn.Read(reply)
		if err != nil || n < 20 {
			return false
		}
		// 原始套接字读出的是完整 IP 包，源地址和类型都在头里。
		src := net.IP(reply[12:16]).String()
		if src != ip {
			continue
		}
		if reply[20] == 0 || reply[20] == 8 { // Echo Reply / Reply 被反射回来
			return true
		}
		return false
	}
}

func icmpChecksum(b []byte) uint16 {
	var sum uint32
	for i := 0; i+1 < len(b); i += 2 {
		sum += uint32(binary.BigEndian.Uint16(b[i : i+2]))
	}
	if len(b)%2 == 1 {
		sum += uint32(b[len(b)-1]) << 8
	}
	for sum>>16 != 0 {
		sum = (sum & 0xffff) + (sum >> 16)
	}
	return ^uint16(sum)
}

// smbProbe 发一个 SMB2 NEGOTIATE 请求，确认 445 上的 SMB 服务是否可协商。
func smbProbe(ip string, timeout time.Duration) string {
	conn, err := net.DialTimeout("tcp", net.JoinHostPort(ip, "445"), timeout)
	if err != nil {
		return ""
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(timeout))

	pkt := make([]byte, 0, 96+64)
	hdr := make([]byte, 64)
	copy(hdr[0:4], []byte{0xfe, 'S', 'M', 'B'})
	binary.LittleEndian.PutUint16(hdr[4:6], 64) // StructureSize
	binary.LittleEndian.PutUint16(hdr[12:14], 1)
	binary.LittleEndian.PutUint16(hdr[14:16], 1) // Credits
	binary.LittleEndian.PutUint16(hdr[16:18], 0) // Command NEGOTIATE
	binary.LittleEndian.PutUint64(hdr[24:32], 0) // MessageId

	body := make([]byte, 36+2)
	binary.LittleEndian.PutUint16(body[0:2], 36) // StructureSize
	binary.LittleEndian.PutUint16(body[2:4], 1)  // DialectCount
	binary.LittleEndian.PutUint16(body[4:6], 1)  // SecurityMode
	copy(body[12:28], []byte("relaymgr-probe00"))
	binary.LittleEndian.PutUint16(body[36:38], 0x0202) // SMB 2.0.2

	pkt = append(pkt, hdr...)
	pkt = append(pkt, body...)
	if _, err := conn.Write(pkt); err != nil {
		return ""
	}
	resp := make([]byte, 1024)
	n, err := conn.Read(resp)
	if err != nil || n < 64 {
		return ""
	}
	if string(resp[0:4]) != "\xfeSMB" {
		if n >= 4 && string(resp[0:4]) == "\xffSMB" {
			return "SMB1 已开启（不安全）"
		}
		return "SMB 端口开放"
	}
	status := binary.LittleEndian.Uint32(resp[8:12])
	switch status {
	case 0:
		return "SMB2/3 已开启"
	case 0xC00000FE: // 没有共同方言
		return "SMB 已开启，方言不匹配"
	case 0xC00000FB:
		return "SMB 已开启"
	case 0xFFFFFFFF:
		return "SMB 端口开放"
	default:
		return "SMB 已开启（0x" + strings.ToUpper(hex.EncodeToString([]byte{
			byte(status >> 24), byte(status >> 16), byte(status >> 8), byte(status),
		})) + "）"
	}
}

// scanSpeed 把速度档位换算成并发与超时。
func scanSpeed(speed string, base time.Duration) (conc int, timeout time.Duration) {
	switch strings.ToLower(strings.TrimSpace(speed)) {
	case "fast":
		return 256, base
	case "slow":
		t := base * 2
		if t > 1500*time.Millisecond {
			t = 1500 * time.Millisecond
		}
		return 48, t
	default: // medium
		return 128, base
	}
}

func atoiPort(s string) int {
	n, _ := strconv.Atoi(strings.TrimSpace(s))
	return n
}

func normSpeedLabel(speed string) string {
	switch strings.ToLower(strings.TrimSpace(speed)) {
	case "fast":
		return "256"
	case "slow":
		return "48"
	default:
		return "128"
	}
}
