package main

// 端口转发引擎：TCP 与 UDP 均可，规则热加载，逐条统计连接与流量。

import (
	"fmt"
	"io"
	"log"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

type forwardStat struct {
	Active     atomic.Int64
	Total      atomic.Int64
	BytesIn    atomic.Int64 // 客户端 -> 目标
	BytesOut   atomic.Int64 // 目标 -> 客户端
	LastError  atomic.Value // string
	LastActive atomic.Int64 // unix nano
}

type tunnel struct {
	rule   Forward
	ln     net.Listener
	pc     net.PacketConn
	closer chan struct{}
	once   sync.Once
	wg     sync.WaitGroup
	stat   *forwardStat
}

type ForwardManager struct {
	store   *Store
	audit   *Audit
	mu      sync.Mutex
	tunnels map[string]*tunnel
	stats   map[string]*forwardStat
	started time.Time
}

func NewForwardManager(store *Store, audit *Audit) *ForwardManager {
	return &ForwardManager{
		store:   store,
		audit:   audit,
		tunnels: map[string]*tunnel{},
		stats:   map[string]*forwardStat{},
		started: time.Now(),
	}
}

func (m *ForwardManager) statFor(id string) *forwardStat {
	m.mu.Lock()
	defer m.mu.Unlock()
	if s, ok := m.stats[id]; ok {
		return s
	}
	s := &forwardStat{}
	s.LastError.Store("")
	m.stats[id] = s
	return s
}

// Restore 启动全部已启用的规则。
func (m *ForwardManager) Restore() {
	for _, r := range m.store.Snapshot().Forwards {
		if !r.Enabled {
			continue
		}
		if err := m.Start(r); err != nil {
			log.Printf("[forward] 规则 %s(%d) 启动失败: %v", r.Name, r.Listen, err)
		}
	}
}

func (m *ForwardManager) Start(rule Forward) error {
	m.Stop(rule.ID)

	m.mu.Lock()
	defer m.mu.Unlock()

	stat := m.statForLocked(rule.ID)
	stat.LastError.Store("")
	t := &tunnel{rule: rule, closer: make(chan struct{}), stat: stat}

	if rule.Proto == "udp" {
		pc, _, err := bindUDP(rule.Listen, true)
		if err != nil {
			stat.LastError.Store(err.Error())
			return fmt.Errorf("UDP %d 监听失败: %w", rule.Listen, err)
		}
		t.pc = pc
		m.tunnels[rule.ID] = t
		t.wg.Add(1)
		go m.serveUDP(t)
		log.Printf("[forward] UDP %d -> %s:%d 已启动", rule.Listen, rule.TargetHost, rule.TargetPort)
		return nil
	}

	ln, _, err := bindTCP(rule.Listen, true)
	if err != nil {
		stat.LastError.Store(err.Error())
		return fmt.Errorf("TCP %d 监听失败: %w", rule.Listen, err)
	}
	t.ln = ln
	m.tunnels[rule.ID] = t
	t.wg.Add(1)
	go m.serveTCP(t)
	log.Printf("[forward] TCP %d -> %s:%d 已启动", rule.Listen, rule.TargetHost, rule.TargetPort)
	return nil
}

func (m *ForwardManager) statForLocked(id string) *forwardStat {
	if s, ok := m.stats[id]; ok {
		return s
	}
	s := &forwardStat{}
	s.LastError.Store("")
	m.stats[id] = s
	return s
}

// Stop 关闭监听并等待连接处理协程退出。
func (m *ForwardManager) Stop(id string) {
	m.mu.Lock()
	t, ok := m.tunnels[id]
	if ok {
		delete(m.tunnels, id)
	}
	m.mu.Unlock()
	if !ok {
		return
	}
	t.once.Do(func() {
		close(t.closer)
		if t.ln != nil {
			t.ln.Close()
		}
		if t.pc != nil {
			t.pc.Close()
		}
	})
	done := make(chan struct{})
	go func() {
		t.wg.Wait()
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		log.Printf("[forward] 规则 %s 停止超时，继续", id)
	}
}

func (m *ForwardManager) StopAll() {
	m.mu.Lock()
	ids := make([]string, 0, len(m.tunnels))
	for id := range m.tunnels {
		ids = append(ids, id)
	}
	m.mu.Unlock()
	for _, id := range ids {
		m.Stop(id)
	}
}

// Upsert 保存规则并按需启停。
func (m *ForwardManager) Upsert(rule Forward) error {
	var prev *Forward
	if err := m.store.Update(func(cfg *Config) error {
		for i := range cfg.Forwards {
			if cfg.Forwards[i].ID == rule.ID {
				old := cfg.Forwards[i]
				prev = &old
				cfg.Forwards[i] = rule
				return nil
			}
		}
		cfg.Forwards = append(cfg.Forwards, rule)
		return nil
	}); err != nil {
		return err
	}
	m.Stop(rule.ID)
	if rule.Enabled {
		if err := m.Start(rule); err != nil {
			// 监听失败必须回滚配置：否则会留下一条占着端口却永远起不来的规则，
			// 用户再建同端口规则会被"端口已被占用"挡住，且重启后又会尝试拉起。
			_ = m.store.Update(func(cfg *Config) error {
				out := cfg.Forwards[:0]
				for _, r := range cfg.Forwards {
					if r.ID == rule.ID {
						if prev != nil {
							out = append(out, *prev)
						}
						continue
					}
					out = append(out, r)
				}
				cfg.Forwards = out
				return nil
			})
			if prev != nil && prev.Enabled {
				_ = m.Start(*prev)
			}
			return err
		}
	}
	return nil
}

// Delete 删除规则并停止转发。
func (m *ForwardManager) Delete(id string) error {
	m.Stop(id)
	return m.store.Update(func(cfg *Config) error {
		out := cfg.Forwards[:0]
		for _, r := range cfg.Forwards {
			if r.ID != id {
				out = append(out, r)
			}
		}
		cfg.Forwards = out
		return nil
	})
}

// SetEnabled 启用或停用单条规则。
func (m *ForwardManager) SetEnabled(id string, enabled bool) error {
	var rule Forward
	found := false
	if err := m.store.Update(func(cfg *Config) error {
		for i := range cfg.Forwards {
			if cfg.Forwards[i].ID == id {
				cfg.Forwards[i].Enabled = enabled
				rule = cfg.Forwards[i]
				found = true
			}
		}
		return nil
	}); err != nil {
		return err
	}
	if !found {
		return fmt.Errorf("规则不存在")
	}
	m.Stop(id)
	if enabled {
		return m.Start(rule)
	}
	return nil
}

func (m *ForwardManager) serveTCP(t *tunnel) {
	defer t.wg.Done()
	target := net.JoinHostPort(t.rule.TargetHost, fmt.Sprint(t.rule.TargetPort))
	for {
		c, err := t.ln.Accept()
		if err != nil {
			select {
			case <-t.closer:
				return
			default:
				log.Printf("[forward] accept 结束: %v", err)
				return
			}
		}
		t.wg.Add(1)
		go func(client net.Conn) {
			defer t.wg.Done()
			defer client.Close()
			up, err := net.DialTimeout("tcp", target, 5*time.Second)
			if err != nil {
				t.stat.LastError.Store(err.Error())
				return
			}
			defer up.Close()
			t.stat.Active.Add(1)
			t.stat.Total.Add(1)
			t.stat.LastActive.Store(time.Now().UnixNano())
			defer t.stat.Active.Add(-1)

			done := make(chan struct{}, 2)
			go func() {
				n, _ := io.Copy(up, client)
				t.stat.BytesIn.Add(n)
				done <- struct{}{}
			}()
			go func() {
				n, _ := io.Copy(client, up)
				t.stat.BytesOut.Add(n)
				done <- struct{}{}
			}()
			<-done
		}(c)
	}
}

type udpSession struct {
	up       net.Conn
	lastUsed atomic.Int64
}

func (m *ForwardManager) serveUDP(t *tunnel) {
	defer t.wg.Done()
	pc := t.pc.(*net.UDPConn)
	target := net.JoinHostPort(t.rule.TargetHost, fmt.Sprint(t.rule.TargetPort))
	var mu sync.Mutex
	sessions := map[string]*udpSession{}

	// 清理 60 秒无活动的会话。
	go func() {
		tk := time.NewTicker(30 * time.Second)
		defer tk.Stop()
		for {
			select {
			case <-t.closer:
				return
			case <-tk.C:
			}
			now := time.Now().UnixNano()
			mu.Lock()
			for k, s := range sessions {
				if now-s.lastUsed.Load() > int64(60*time.Second) {
					s.up.Close()
					delete(sessions, k)
				}
			}
			mu.Unlock()
		}
	}()

	buf := make([]byte, 4096)
	for {
		n, addr, err := pc.ReadFromUDP(buf)
		if err != nil {
			select {
			case <-t.closer:
				return
			default:
				log.Printf("[forward] udp 读取结束: %v", err)
				return
			}
		}
		key := addr.String()
		mu.Lock()
		s, ok := sessions[key]
		if !ok {
			up, derr := net.DialTimeout("udp", target, 5*time.Second)
			if derr != nil {
				mu.Unlock()
				t.stat.LastError.Store(derr.Error())
				continue
			}
			s = &udpSession{up: up}
			s.lastUsed.Store(time.Now().UnixNano())
			sessions[key] = s
			go func(sess *udpSession, client *net.UDPAddr) {
				b := make([]byte, 4096)
				for {
					sess.up.SetReadDeadline(time.Now().Add(60 * time.Second))
					rn, rerr := sess.up.Read(b)
					if rerr != nil {
						return
					}
					sess.lastUsed.Store(time.Now().UnixNano())
					t.stat.BytesOut.Add(int64(rn))
					if _, werr := pc.WriteToUDP(b[:rn], client); werr != nil {
						return
					}
				}
			}(s, addr)
		}
		mu.Unlock()
		if _, err := s.up.Write(buf[:n]); err == nil {
			t.stat.BytesIn.Add(int64(n))
			s.lastUsed.Store(time.Now().UnixNano())
			t.stat.LastActive.Store(time.Now().UnixNano())
		}
	}
}

// Stats 汇总每条规则的运行状态。
func (m *ForwardManager) Stats() map[string]map[string]any {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make(map[string]map[string]any, len(m.stats))
	for id, s := range m.stats {
		_, running := m.tunnels[id]
		last := s.LastActive.Load()
		item := map[string]any{
			"running":    running,
			"active":     s.Active.Load(),
			"total":      s.Total.Load(),
			"bytesIn":    s.BytesIn.Load(),
			"bytesOut":   s.BytesOut.Load(),
			"lastError":  s.LastError.Load(),
			"lastActive": last,
		}
		out[id] = item
	}
	return out
}
