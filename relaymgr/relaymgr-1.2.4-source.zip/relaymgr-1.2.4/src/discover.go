package main

// 内网主机发现：读取 ARP 表 + 并发 TCP 端口探测，识别系统类型并可直接转成转发规则。

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type Host struct {
	IP        string    `json:"ip"`
	MAC       string    `json:"mac"`
	Hostname  string    `json:"hostname"`
	Vendor    string    `json:"vendor"`
	Kind      string    `json:"kind"`
	OpenPorts []int     `json:"openPorts"`
	Services  []Service `json:"services,omitempty"`
	Flags     []string  `json:"flags,omitempty"`
	Risks     []string  `json:"risks,omitempty"`
	SMB       string    `json:"smb,omitempty"`
	Range     string    `json:"range,omitempty"`
	LastSeen  time.Time `json:"lastSeen"`
}

// ScanOptions 对应扫描页上的开关：速度、探活方式、强扫、SMB 检查。
type ScanOptions struct {
	Speed     string `json:"speed"`
	UsePing   bool   `json:"usePing"`
	ForcePort bool   `json:"forcePort"`
	CheckSMB  bool   `json:"checkSMB"`
}

type ScanStatus struct {
	Running    bool      `json:"running"`
	CIDR       string    `json:"cidr"`
	Profile    string    `json:"profile"`
	Phase      string    `json:"phase"`
	CurrentIP  string    `json:"currentIp"`
	Total      int       `json:"total"`
	Done       int       `json:"done"`
	Found      int       `json:"found"`
	Percent    int       `json:"percent"`
	NewCount   int       `json:"newCount"`
	GoneCount  int       `json:"goneCount"`
	Gone       []string  `json:"gone,omitempty"`
	ElapsedMs  int64     `json:"elapsedMs"`
	Canceled   bool      `json:"canceled"`
	StartedAt  time.Time `json:"startedAt"`
	FinishedAt time.Time `json:"finishedAt"`
	Error      string    `json:"error"`
	Conc       int       `json:"conc,omitempty"`
	Note       string    `json:"note,omitempty"`
}

// 地址数不超过该值时不做「存活剪枝」：每个地址直接探完整端口表，
// 否则只开放冷门端口（如 8080、9099）的主机会被判成不在线而永远扫不出来。
const pruneFreeAddrs = 256

type Discovery struct {
	mu       sync.Mutex
	status   ScanStatus
	hosts    []Host
	dataPath string
	timeout  time.Duration
	cancel   context.CancelFunc
}

// dedupeHosts 按 IP 去重，保留端口更全 / 更近一次的那条。
// 1.1.5 曾把旧记录和新记录当成两条，升级后启动即清理，不让用户看到重复行。
func dedupeHosts(list []Host) []Host {
	seen := map[string]Host{}
	order := []string{}
	for _, h := range list {
		prev, ok := seen[h.IP]
		if !ok {
			seen[h.IP] = h
			order = append(order, h.IP)
			continue
		}
		better := len(h.OpenPorts) >= len(prev.OpenPorts) || h.LastSeen.After(prev.LastSeen)
		if better {
			seen[h.IP] = h
		}
	}
	out := make([]Host, 0, len(order))
	for _, ip := range order {
		out = append(out, seen[ip])
	}
	sort.Slice(out, func(i, j int) bool { return ipLess(out[i].IP, out[j].IP) })
	return out
}

func NewDiscovery(dataDir string) *Discovery {
	d := &Discovery{
		dataPath: filepath.Join(dataDir, "hosts.json"),
		timeout:  300 * time.Millisecond,
	}
	if b, err := os.ReadFile(d.dataPath); err == nil {
		var raw []Host
		if json.Unmarshal(b, &raw) == nil {
			d.hosts = dedupeHosts(raw)
			if len(d.hosts) != len(raw) {
				if out, err := json.MarshalIndent(d.hosts, "", "  "); err == nil {
					_ = os.WriteFile(d.dataPath, out, 0o600)
				}
			}
		}
	}
	return d
}

// Interfaces 返回本机所有 IPv4 网段（用于扫描下拉框）。
func (d *Discovery) Interfaces() []map[string]string {
	out := []map[string]string{}
	ifs, err := net.Interfaces()
	if err != nil {
		return out
	}
	for _, ifc := range ifs {
		if ifc.Flags&net.FlagLoopback != 0 || ifc.Flags&net.FlagUp == 0 {
			continue
		}
		addrs, err := ifc.Addrs()
		if err != nil {
			continue
		}
		for _, a := range addrs {
			ipnet, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			ip4 := ipnet.IP.To4()
			if ip4 == nil || !isPrivateIP(ipnet.IP) {
				continue
			}
			out = append(out, map[string]string{
				"name": ifc.Name,
				"ip":   ip4.String(),
				"cidr": ipnet.String(),
			})
		}
	}
	return out
}

func (d *Discovery) Hosts() []Host {
	d.mu.Lock()
	defer d.mu.Unlock()
	out := make([]Host, len(d.hosts))
	copy(out, d.hosts)
	return out
}

func (d *Discovery) Status() ScanStatus {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.status
}

func (d *Discovery) SetTimeout(ms int) {
	if ms < 50 {
		ms = 50
	}
	if ms > 3000 {
		ms = 3000
	}
	d.timeout = time.Duration(ms) * time.Millisecond
}

// Start 异步扫描指定网段；profile 取 fast/standard/deep/custom，custom 时用 ports 指定端口。
func (d *Discovery) Start(cidr, profile, ports string, concReq int, opts ScanOptions) error {
	cidr = strings.TrimSpace(cidr)
	if cidr == "" {
		return errors.New("请选择或输入要扫描的网段")
	}
	ips, err := expandRanges(cidr)
	if err != nil {
		return err
	}
	if len(ips) == 0 {
		return errors.New("网段内没有可用地址")
	}
	if len(ips) > maxScanAddrs {
		return errors.New("扫描范围过大：单次最多 65536 个地址（/16），请缩小或分批")
	}
	portList, err := resolvePorts(profile, ports)
	if err != nil {
		return err
	}
	if len(portList) >= 65535 && len(ips) > 1 {
		return errors.New("全端口扫描一次只能扫 1 个 IP，请把范围改成单个地址，例如 192.168.1.50")
	}
	if len(ips) > 4096 && strings.ToLower(strings.TrimSpace(profile)) == "deep" {
		return errors.New("地址数超过 4096 时「深度」档会非常慢（约 390 万次连接），请改用快速或标准档，或缩小范围")
	}

	d.mu.Lock()
	if d.status.Running {
		d.mu.Unlock()
		return errors.New("已有扫描任务正在运行，可先点「停止」")
	}
	prev := make(map[string]Host, len(d.hosts))
	for _, h := range d.hosts {
		if h.Range == cidr || h.Range == "" {
			prev[h.IP] = h
		}
	}
	prevCIDR := d.status.CIDR
	ctx, cancel := context.WithCancel(context.Background())
	d.cancel = cancel
	total := len(ips)
	phase := "探测存活"
	conc := 0
	note := ""
	if len(portList) >= 65535 {
		total = len(ips) * len(portList)
		phase = "全端口扫描"
		// 先用一组样本判断目标是否回包：大量超时说明设备限流或防火墙丢弃，
		// 这时 256 并发会把弱设备（ESP、单片机、老路由）的连接槽打满，反而漏端口。
		conc = 192
		if opts.Speed != "" {
			conc, _ = scanSpeed(opts.Speed, d.timeout)
			note = "按所选的扫描速度使用并发 " + normSpeedLabel(opts.Speed) + "；弱设备建议用慢速"
		} else if concReq >= 8 && concReq <= 256 {
			conc = concReq
			note = "使用手动并发 " + strconv.Itoa(conc) + " 扫描；目标较弱时并发越低越不容易漏端口，但耗时更长"
		} else if len(ips) == 1 {
			sample := fullSamplePorts()
			_, timeouts := probeSample(ips[0], sample, d.timeout)
			if timeouts*2 > len(sample) {
				conc = 48
				note = "目标对多数端口不回包（设备限流或防火墙），已自动降低并发；若仍扫不全，可在「设置」里把扫描超时调大后重试"
			}
		}
	}
	d.status = ScanStatus{
		Running:   true,
		CIDR:      cidr,
		Total:     total,
		Phase:     phase,
		StartedAt: time.Now(),
		Profile:   profileLabel(profile),
		Conc:      conc,
		Note:      note,
	}
	d.mu.Unlock()

	go d.scan(ctx, cidr, ips, portList, prev, prevCIDR, conc, opts)
	return nil
}

// Stop 取消正在运行的扫描，已探测到的结果会保留。
func (d *Discovery) Stop() {
	d.mu.Lock()
	cancel := d.cancel
	if d.status.Running {
		d.status.Phase = "正在停止"
	}
	d.mu.Unlock()
	if cancel != nil {
		cancel()
	}
}

func profileLabel(p string) string {
	switch strings.ToLower(strings.TrimSpace(p)) {
	case "fast":
		return "快速"
	case "deep":
		return "深度"
	case "full":
		return "全端口"
	case "custom":
		return "自定义端口"
	default:
		return "标准"
	}
}

// mergeHostList 合并历史结果，保证同一 IP 只留一条，本轮结果优先。
// 旧版本（1.1.4 及更早）的 hosts.json 没有 range 字段，这类记录只要 IP 落在本轮扫描范围内
// 就视为同一条，否则升级后同一个 IP 会出现两行（旧记录 + 新记录）。
func mergeHostList(old, fresh []Host, cidr string, scanned map[string]bool) []Host {
	foundIP := make(map[string]bool, len(fresh))
	for _, h := range fresh {
		foundIP[h.IP] = true
	}
	out := make([]Host, 0, len(old)+len(fresh))
	for _, h := range old {
		if foundIP[h.IP] {
			continue
		}
		if h.Range == cidr {
			continue
		}
		if h.Range == "" && scanned[h.IP] {
			continue
		}
		out = append(out, h)
	}
	out = append(out, fresh...)
	sort.Slice(out, func(i, j int) bool { return ipLess(out[i].IP, out[j].IP) })
	return out
}

func (d *Discovery) scan(ctx context.Context, cidr string, ips []string, portList []int, prev map[string]Host, prevCIDR string, conc int, opts ScanOptions) {
	arp := readARP()
	self := localIPv4Set()
	gateway := defaultGateway()
	timeout := d.timeout
	if opts.Speed != "" {
		sc, st := scanSpeed(opts.Speed, d.timeout)
		timeout = st
		if conc <= 0 {
			conc = sc
		}
	}

	fullPorts := len(portList) >= 65535
	noPrune := !fullPorts && len(ips) <= pruneFreeAddrs

	var first []int
	var rest []int
	switch {
	case fullPorts:
		rest = nil
	case noPrune:
		// 地址不多：不做存活剪枝，全部地址直接过完整端口表。
		rest = portList
	default:
		first = scanFirstWave(portList)
		if len(ips) > 4096 && len(first) > 4 {
			// 大范围扫描只探前 4 个高价值端口，避免把局域网和路由器打满。
			first = first[:4]
		}
		rest = portsExcept(portList, first)
	}

	alive := make(map[string][]int, len(ips))
	var mu sync.Mutex
	var done atomic.Int64
	var persistMu sync.Mutex
	scanned := make(map[string]bool, len(ips))
	for _, ip := range ips {
		scanned[ip] = true
	}
	sem := make(chan struct{}, 48)
	var wg sync.WaitGroup

	persist := func(list []Host) {
		persistMu.Lock()
		defer persistMu.Unlock()
		d.mu.Lock()
		old := append([]Host{}, d.hosts...)
		d.mu.Unlock()
		all := mergeHostList(old, list, cidr, scanned)
		if b, err := json.MarshalIndent(all, "", "  "); err == nil {
			_ = os.WriteFile(d.dataPath, b, 0o600)
		}
	}

	if fullPorts {
		totalPorts := len(ips) * len(portList)
		if conc <= 0 {
			conc = 192
		}
		progress := func() {
			n := int(done.Add(1))
			if n%512 != 0 && n != totalPorts {
				return
			}
			d.mu.Lock()
			d.status.Done = n
			if totalPorts > 0 {
				d.status.Percent = n * 90 / totalPorts
			}
			d.mu.Unlock()
		}
		d.mu.Lock()
		d.status.Phase = "全端口扫描"
		d.status.Total = totalPorts
		d.mu.Unlock()
		for _, ip := range ips {
			if ctx.Err() != nil {
				break
			}
			ports := probePortsAdv(ctx, ip, portList, d.timeout, conc, progress)
			mu.Lock()
			alive[ip] = ports
			mu.Unlock()
			d.mu.Lock()
			d.status.CurrentIP = ip
			d.mu.Unlock()
		}
		done.Store(int64(totalPorts))
	} else if noPrune {
		d.mu.Lock()
		d.status.Phase = "端口探测"
		d.status.Total = len(ips)
		d.mu.Unlock()
		for _, ip := range ips {
			alive[ip] = nil
		}
	} else {
	loop1:
		for _, ip := range ips {
			select {
			case <-ctx.Done():
				break loop1
			case sem <- struct{}{}:
			}
			wg.Add(1)
			go func(ip string) {
				defer func() { <-sem; wg.Done() }()
				ports := probePorts(ip, first, timeout)
				hit := len(ports) > 0
				if !hit && opts.UsePing {
					hit = icmpPing(ip, timeout)
				}
				if !hit && !opts.UsePing {
					if mac, ok := arp[ip]; ok && mac != "" && mac != "00:00:00:00:00:00" {
						hit = true
					}
				}
				if !hit && opts.ForcePort {
					hit = true
				}
				if hit {
					mu.Lock()
					alive[ip] = ports
					mu.Unlock()
				}
				n := int(done.Add(1))
				d.mu.Lock()
				d.status.Done = n
				d.status.CurrentIP = ip
				if d.status.Total > 0 {
					d.status.Percent = n * 90 / d.status.Total
				}
				d.mu.Unlock()
			}(ip)
		}
		wg.Wait()
	}

	aliveIPs := make([]string, 0, len(alive))
	for ip := range alive {
		aliveIPs = append(aliveIPs, ip)
	}
	sort.Slice(aliveIPs, func(i, j int) bool { return ipLess(aliveIPs[i], aliveIPs[j]) })

	d.mu.Lock()
	d.status.Phase = "识别服务"
	d.status.CurrentIP = ""
	d.mu.Unlock()

	found := make([]Host, 0, len(aliveIPs))
	var done2 atomic.Int64
	semSize := 8
	if noPrune {
		semSize = 24
	}
	sem2 := make(chan struct{}, semSize)
	var wg2 sync.WaitGroup

	fpLimit := 12
	if fullPorts {
		fpLimit = 64
	}

loop2:
	for _, ip := range aliveIPs {
		select {
		case <-ctx.Done():
			break loop2
		case sem2 <- struct{}{}:
		}
		wg2.Add(1)
		go func(ip string) {
			defer func() { <-sem2; wg2.Done() }()
			probed := probePortsAdv(ctx, ip, rest, timeout, 12, nil)
			mu.Lock()
			ports := mergePorts(alive[ip], probed)
			mu.Unlock()
			// 不做存活剪枝时所有地址都会被探到，只有真正有响应的才算主机，
			// 否则扫 /24 会入库上百台“未知”幽灵记录。
			keep := len(ports) > 0 || self[ip] || (gateway != "" && ip == gateway) || len(ips) == 1
			if !keep {
				if mac, ok := arp[ip]; ok && mac != "" && mac != "00:00:00:00:00:00" {
					keep = true
				}
			}
			if !keep {
				n := int(done2.Add(1))
				d.mu.Lock()
				d.status.CurrentIP = ip
				switch {
				case noPrune:
					d.status.Done = n
					if len(ips) > 0 {
						d.status.Percent = n * 100 / len(ips)
					}
				case fullPorts:
					if len(aliveIPs) > 0 {
						d.status.Percent = 90 + n*10/len(aliveIPs)
					}
				default:
					d.status.Done = n
					if len(aliveIPs) > 0 {
						d.status.Percent = 90 + n*9/len(aliveIPs)
					}
				}
				d.mu.Unlock()
				return
			}
			h := Host{IP: ip, MAC: arp[ip], OpenPorts: ports, LastSeen: time.Now(), Range: cidr}
			h.Services = fingerprints(ip, ports, timeout, fpLimit)
			h.Kind = guessKindEnhanced(ports, h.Services, h.MAC)
			h.Vendor = ouiVendor(h.MAC)
			h.Hostname = lookupName(ip)
			h.Risks = risksFor(ports)
			h.Flags = flagsFor(ip, self, gateway, prev, prevCIDR, cidr)
			if opts.CheckSMB {
				for _, p := range ports {
					if p == 445 || p == 139 {
						h.SMB = smbProbe(ip, timeout)
						break
					}
				}
			}

			mu.Lock()
			found = append(found, h)
			snapshot := make([]Host, len(found))
			copy(snapshot, found)
			mu.Unlock()

			n := int(done2.Add(1))
			d.mu.Lock()
			d.status.CurrentIP = ip
			d.status.Found = len(found)
			switch {
			case noPrune:
				d.status.Done = n
				if len(ips) > 0 {
					d.status.Percent = n * 100 / len(ips)
				}
			case fullPorts:
				if len(aliveIPs) > 0 {
					d.status.Percent = 90 + n*10/len(aliveIPs)
				}
			default:
				d.status.Done = n
				if len(aliveIPs) > 0 {
					d.status.Percent = 90 + n*9/len(aliveIPs)
				}
			}
			d.mu.Unlock()

			// 扫描过程中每 8 台落一次盘，进程被杀也不会丢掉已扫到的结果。
			if n%8 == 0 {
				persist(snapshot)
			}
		}(ip)
	}
	wg2.Wait()

	sort.Slice(found, func(i, j int) bool { return ipLess(found[i].IP, found[j].IP) })
	newCount, gone := diffHosts(found, prev, prevCIDR, cidr)

	d.mu.Lock()
	merged := mergeHostList(append([]Host{}, d.hosts...), found, cidr, scanned)
	d.hosts = merged
	st := &d.status
	st.Running = false
	st.Found = len(found)
	st.CurrentIP = ""
	st.NewCount = newCount
	st.GoneCount = len(gone)
	st.Gone = gone
	st.FinishedAt = time.Now()
	st.ElapsedMs = time.Since(st.StartedAt).Milliseconds()
	if ctx.Err() != nil {
		st.Canceled = true
		st.Phase = "已停止"
	} else {
		st.Phase = "完成"
		st.Percent = 100
	}
	d.mu.Unlock()

	if b, err := json.MarshalIndent(merged, "", "  "); err == nil {
		_ = os.WriteFile(d.dataPath, b, 0o600)
	}
}

// diffHosts 对比上一轮结果：统计新增主机，同网段时给消失的主机。
func diffHosts(found []Host, prev map[string]Host, prevCIDR, cidr string) (int, []string) {
	gone := []string{}
	// 只有扫描范围与上一轮完全一致时才有可比性，否则不统计新增/消失。
	if prevCIDR == "" || prevCIDR != cidr {
		return 0, gone
	}
	newCount := 0
	for _, h := range found {
		if _, ok := prev[h.IP]; !ok {
			newCount++
		}
	}
	cur := map[string]bool{}
	for _, h := range found {
		cur[h.IP] = true
	}
	for ip := range prev {
		if !cur[ip] {
			gone = append(gone, ip)
		}
	}
	sort.Slice(gone, func(i, j int) bool { return ipLess(gone[i], gone[j]) })
	return newCount, gone
}

func mergePorts(a, b []int) []int {
	seen := map[int]bool{}
	out := []int{}
	for _, p := range append(a, b...) {
		if !seen[p] {
			seen[p] = true
			out = append(out, p)
		}
	}
	sort.Ints(out)
	return out
}

func probePorts(ip string, ports []int, timeout time.Duration) []int {
	return probePortsAdv(context.Background(), ip, ports, timeout, 16, nil)
}

// probePortsAdv 用固定 worker 池探测端口，并响应 ctx 取消（全端口扫描不能等 65535 次探测跑完才停）。
func probePortsAdv(ctx context.Context, ip string, ports []int, timeout time.Duration, conc int, onDone func()) []int {
	out := []int{}
	var mu sync.Mutex
	if len(ports) == 0 {
		return out
	}
	workers := conc
	if workers < 1 {
		workers = 1
	}
	if workers > len(ports) {
		workers = len(ports)
	}
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				select {
				case <-ctx.Done():
					return
				case port, ok := <-jobs:
					if !ok {
						return
					}
					conn, err := net.DialTimeout("tcp", net.JoinHostPort(ip, fmt.Sprint(port)), timeout)
					if err == nil {
						conn.Close()
						mu.Lock()
						out = append(out, port)
						mu.Unlock()
					}
					if onDone != nil {
						onDone()
					}
				}
			}
		}()
	}
send:
	for _, p := range ports {
		select {
		case <-ctx.Done():
			break send
		case jobs <- p:
		}
	}
	close(jobs)
	wg.Wait()
	sort.Ints(out)
	return out
}

func lookupName(ip string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 1200*time.Millisecond)
	defer cancel()
	resolver := net.Resolver{}
	names, err := resolver.LookupAddr(ctx, ip)
	if err != nil || len(names) == 0 {
		return ""
	}
	return strings.TrimSuffix(names[0], ".")
}

func guessKind(ports []int, mac string) string {
	has := func(p int) bool {
		for _, x := range ports {
			if x == p {
				return true
			}
		}
		return false
	}
	switch {
	case has(5666) || has(5667):
		return "飞牛 NAS"
	case has(3389):
		return "Windows"
	case has(5900) || has(5901):
		return "VNC 主机"
	case has(9100):
		return "打印机"
	case has(5000) || has(5001):
		return "群晖 NAS"
	case has(445) || has(139):
		return "Windows / SMB"
	case has(22):
		return "Linux / Unix"
	case has(80) || has(443) || has(8080):
		return "Web 设备"
	}
	if mac != "" {
		return "在线设备"
	}
	return "未知"
}

func readARP() map[string]string {
	out := map[string]string{}
	b, err := os.ReadFile("/proc/net/arp")
	if err != nil {
		return out
	}
	lines := strings.Split(string(b), "\n")
	for i, line := range lines {
		if i == 0 {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		if fields[2] != "0x2" {
			continue
		}
		out[fields[0]] = strings.ToLower(fields[3])
	}
	return out
}

var ouiTable = map[string]string{
	"00:11:32": "Synology",
	"00:1a:79": "Synology",
	"00:1b:21": "Intel",
	"3c:7c:3f": "Intel",
	"00:1c:42": "Parallels",
	"00:0c:29": "VMware",
	"00:50:56": "VMware",
	"00:05:69": "VMware",
	"b8:27:eb": "树莓派",
	"dc:a6:32": "树莓派",
	"e4:5f:01": "树莓派",
	"00:25:90": "Supermicro",
	"24:5e:be": "QNAP",
	"f0:9f:fc": "Huawei",
	"78:d7:52": "Huawei",
	"00:e0:fc": "Huawei",
	"28:6c:07": "Xiaomi",
	"50:8f:4c": "Xiaomi",
	"64:b4:73": "Xiaomi",
	"34:ce:00": "Xiaomi",
	"50:64:2b": "TP-Link",
	"ec:26:ca": "TP-Link",
	"c4:6e:1f": "TP-Link",
	"00:1d:0f": "TP-Link",
	"f4:8e:38": "Dell",
	"18:03:73": "Dell",
	"b4:2e:99": "Gigabyte",
	"00:1b:78": "HP",
	"3c:d9:2b": "HP",
	"ac:1f:6b": "Supermicro",
	"00:15:17": "Intel",
}

func ouiVendor(mac string) string {
	if len(mac) < 8 {
		return ""
	}
	if v, ok := ouiTable[strings.ToLower(mac[:8])]; ok {
		return v
	}
	return ""
}

const maxScanAddrs = 65536

// expandRanges 解析扫描范围：支持 CIDR、单个 IP、a-b 区间，多个用逗号/空格/分号分隔。
func expandRanges(input string) ([]string, error) {
	seen := map[string]bool{}
	out := []string{}
	for _, tok := range strings.FieldsFunc(input, func(r rune) bool {
		return r == ',' || r == ' ' || r == ';' || r == '\n' || r == '\t' || r == '、' || r == '，'
	}) {
		tok = strings.TrimSpace(tok)
		if tok == "" {
			continue
		}
		ips, err := expandOne(tok)
		if err != nil {
			return nil, err
		}
		for _, ip := range ips {
			if seen[ip] {
				continue
			}
			seen[ip] = true
			out = append(out, ip)
			if len(out) > maxScanAddrs {
				return nil, errors.New("扫描范围过大：单次最多 65536 个地址（/16），请缩小或分批")
			}
		}
	}
	if len(out) == 0 {
		return nil, errors.New("请选择或输入要扫描的网段")
	}
	sort.Slice(out, func(i, j int) bool { return ipLess(out[i], out[j]) })
	return out, nil
}

func expandOne(tok string) ([]string, error) {
	switch {
	case strings.Contains(tok, "/"):
		return expandCIDR(tok)
	case strings.Contains(tok, "-"):
		return expandDash(tok)
	default:
		ip := net.ParseIP(tok)
		if ip == nil || ip.To4() == nil {
			return nil, fmt.Errorf("IP 格式不正确: %s", tok)
		}
		return []string{ip.To4().String()}, nil
	}
}

// expandDash 解析 a.b.c.1-a.b.c.254 或 192.168.1.10-20 这类区间。
func expandDash(tok string) ([]string, error) {
	segs := strings.SplitN(tok, "-", 2)
	startStr := strings.TrimSpace(segs[0])
	endStr := strings.TrimSpace(segs[1])
	start := net.ParseIP(startStr)
	if start == nil || start.To4() == nil {
		return nil, fmt.Errorf("区间格式不正确: %s", tok)
	}
	start4 := start.To4()
	var end net.IP
	if strings.Contains(endStr, ".") {
		end = net.ParseIP(endStr)
		if end == nil || end.To4() == nil {
			return nil, fmt.Errorf("区间格式不正确: %s", tok)
		}
		end = end.To4()
	} else {
		last, err := strconv.Atoi(endStr)
		if err != nil || last < 0 || last > 255 {
			return nil, fmt.Errorf("区间格式不正确: %s", tok)
		}
		end = net.IPv4(start4[0], start4[1], start4[2], byte(last))
	}
	if bytesToU32(end) < bytesToU32(start4) {
		return nil, fmt.Errorf("区间起点大于终点: %s", tok)
	}
	out := []string{}
	cur := make(net.IP, len(start4))
	copy(cur, start4)
	for bytesToU32(cur) <= bytesToU32(end) {
		out = append(out, cur.String())
		if len(out) > maxScanAddrs {
			return nil, errors.New("扫描范围过大：单次最多 65536 个地址（/16），请缩小或分批")
		}
		next := make(net.IP, len(cur))
		copy(next, cur)
		carry := true
		for i := len(next) - 1; i >= 0 && carry; i-- {
			if next[i] == 255 {
				next[i] = 0
			} else {
				next[i]++
				carry = false
			}
		}
		if carry {
			break
		}
		cur = next
	}
	return out, nil
}

func bytesToU32(ip net.IP) uint32 {
	ip = ip.To4()
	if ip == nil {
		return 0
	}
	return uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
}

func expandCIDR(cidr string) ([]string, error) {
	if !strings.Contains(cidr, "/") {
		ip := net.ParseIP(cidr)
		if ip == nil || ip.To4() == nil {
			return nil, errors.New("IP 格式不正确")
		}
		return []string{ip.To4().String()}, nil
	}
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		return nil, errors.New("网段格式不正确，例如 192.168.1.0/24")
	}
	start := ipnet.IP.To4()
	if start == nil {
		return nil, errors.New("仅支持 IPv4 网段")
	}
	if ones, bits := ipnet.Mask.Size(); bits == 32 && ones < 16 {
		return nil, errors.New("网段过大：最大支持 /16（65536 个地址），请缩小范围或用逗号分批")
	}
	out := []string{}
	cur := make(net.IP, len(start))
	copy(cur, start)
	for ipnet.Contains(cur) && len(out) < maxScanAddrs {
		out = append(out, cur.String())
		next := make(net.IP, len(cur))
		copy(next, cur)
		carry := true
		for i := len(next) - 1; i >= 0 && carry; i-- {
			if next[i] == 255 {
				next[i] = 0
			} else {
				next[i]++
				carry = false
			}
		}
		if carry {
			break
		}
		cur = next
	}
	return out, nil
}

func ipLess(a, b string) bool {
	ia := net.ParseIP(a).To4()
	ib := net.ParseIP(b).To4()
	if ia == nil || ib == nil {
		return a < b
	}
	for i := 0; i < 4; i++ {
		if ia[i] != ib[i] {
			return ia[i] < ib[i]
		}
	}
	return false
}
